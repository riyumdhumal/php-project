<?php
session_start();
$u_type=$_SESSION['user_type'];
$u_name=$_SESSION['name'];

?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous"></head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<style>

body {
  margin: 0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: auto;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin:0px;
	
}
.animateuse{
	animation:headanimate 0.5s infinite;
	
}
@keyframes headanimate{
	
	0%{color:red},
	10%{color:yellow},
	20%{color:blue},
	40%{color:green},
	50%{color:pink},
	60%{color:orange},
	80%{color:black},
	100%{color:brown}
	
}
.colr{
	background-color:#fa824b;
	
}


</style>




</head>
<body>
<div class="header" id="">
<h4 class=" text-success "><b  style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;<i class="animateuse" style="margin-left:0%;" >Online Examination System
</i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i   class="fas fa-sign-out-alt"><a href="logout.php"> Sign-out</a></i> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user">&nbsp;&nbsp;</i><?php echo $u_name."(".$u_type.")";?>
</button>

</h4>
</div>

<div class="sidebar" id="">
  <a class="active" href="#home"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
  <a href="exam.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Exam</a>
  <a href="#subject"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Subject</a>
  <a href="#about"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
</div>


<div class="content">


<div class="cointainer">
<div class="col-md-12-offset-">
		<div class="col-md-2">
				<div class="panel panel-body colr">
				<h1><i class="fas fa-book-open	"></i>&nbsp;&nbsp;Subjects<br></h1>
			</div>	
				
		</div>
	
				
		 <div class="col-md-2">
				<div class="panel panel-body colr">
				<h1><i class="fa fa-bar-chart"></i>&nbsp;&nbsp;Ranking</h1></div>	
		 </div>
		 
		<div class="col-md-4">
				<div class="panel panel-body colr">
				<h1><a href="last_exam_score.php"><i class="fas fa-marker"></i>&nbsp;&nbsp;Last_Exam_Score</a></h1></div>	
		 </div>
		
</div>
</div>
</div>

<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();   
});
</script>


</body>
</html>
<br><br>
<?php
 /*
$dataPoints = array( 
	array("label"=>"PHP", "y"=>64.02),
	array("label"=>"JAVA", "y"=>12.55),
	array("label"=>"C", "y"=>8.47),
	array("label"=>"C++", "y"=>6.08),
	array("label"=>"HTML", "y"=>4.29),
	array("label"=>"CSS", "y"=>4.59)
)
 
?>



<script>
window.onload = function() {
 
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Usage Share of Desktop Browsers"
	},
	subtitles: [{
		text: "November 2019"
	}],
	data: [{
		type: "pie",
		yValueFormatString: "#,##0.00\"%\"",
		indexLabel: "{label} ({y})",
		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
}
</script>




<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</div>


<!--*********************************Bar chart******************************--
<div class="content">
 <div id="chart-container">
        <canvas id="graphCanvas"></canvas>
    </div>

	
    <script>
        $(document).ready(function () {
            showGraph();
        });


        function showGraph()
        {
            {
                $.post("data.php",
                function (data)
                {
                    console.log(data);
                     var name = [];
                    var marks = [];

                    for (var i in data) {
                        name.push(data[i].name);
                        marks.push(data[i].opt_marks);
                    }

                    var chartdata = {
                        labels: name,
                        datasets: [
                            {
                                label: 'name opt_marks',
                                backgroundColor: '#49e2ff',
                                borderColor: '#46d5f1',
                                hoverBackgroundColor: '#CCCCCC',
                                hoverBorderColor: '#666666',
                                data: opt_marks;
                            }
                        ]
                    };

                    var graphTarget = $("#graphCanvas");

                    var barGraph = new Chart(graphTarget, {
                        type: 'bar',
                        data: chartdata
                    });
                });
            }
        }
        </script>

*/
			

?>






