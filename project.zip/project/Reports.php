<?php
include('new2.php');
include('conn.php');


	$q="select Name,subject_name,e.total_question,Question_attened,total_marks,obtained_marks from tb_exam_details e 
inner join tb_user u on e.user_id=u.user_id 
inner join tb_subject s on e.subject_code=s.subject_code ";
	$res=mysqli_query($con,$q);
	
?>
	
	<table class="table table-striped">
    <thead>
      <tr>
        <th>Student Name</th>
        <th>Subject Name</th>
        <th>Total Question</th>
        <th>Question Attened</th>
        <th>Total Marks</th>
        <th>Obtained Marks</th>
        <th> </th>
      </tr>
    </thead>
    <tbody>
	<?php
	while($row=mysqli_fetch_array($res))
	{?>
		<tr>
        <td><?php echo $row['Name']; ?></td>
        <td><?php echo $row['subject_name'];?></td>
        <td><?php echo $row['total_question']; ?></td>
        <td><?php echo $row['Question_attened']; ?></td>
        <td><?php echo $row['total_marks']; ?></td>
        <td><?php echo $row['obtained_marks']; ?></td>
       
        <!--<td><button class="success"><a href="Test_DB.php?id=<?php/* echo $row['subject_code'];*/?>">Start</a></button></td>-->
      
	  </tr>
	   <?php
	
	}
    ?>  
     
    </tbody>
  </table>
  <br>


?>