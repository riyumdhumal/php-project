<?php
include('header1.php');
$user_name=$_SESSION['name'];
$user_id=$_SESSION['user_id'];
$scode=$_SESSION['sub_code'];
$total_question=$_SESSION['$tq'];
$start_time=$_SESSION['start_time'];
$count=0;
$result=0;


if(isset($user_name))
{
	//header('location:login.php');
	
?>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>
<body>
<style>
.position
{
	margin-top:60px;
	margin-right:90%;
	}
	.cc{
	background-color:red;
	color:white;
	
}
.tbld{
	padding:20px;
	font-size:24px;
}
</style>
<div class="container">
<!--<div class="text-right" style="margin-top:10px;">
<a href="logout.php"  class="btn btn-primary"><span class="glyphicon glyphicon-log-out"></span> Log out
</a>
</div>-->

<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
		<div class="col-md-8 position ">
		<div class="panel panel- ">
<div class="panel-heading cc text-center "><h2>Result</h2></div><br>
		
<?php
include('conn.php');
error_reporting("E_ALL");

/*session_start();
if(!isset($_SESSION['name'])){
	header('location:login.php');*/
	
	
	//echo $_SESSION['$tq'];
	if(isset($_POST['submit']))
	{
		if(!empty($_POST['quizecheck']))
		{
			$count=count($_POST['quizecheck']);
			$i;
			?>
			
			<div class="panel-body">
			<table class="tbld table table-bordered" width="100%">
			<tr>
			<th>Out of <?php echo $_SESSION['$tq'];?> Questions you are selected</th>
			<td><?php echo $count?></td></tr><br>
				
			<?php				
			//echo "Out of 11,you have selected ".$count."&nbsp; options ";
			?></div></div>
			
			<?php
			$result=0;
			$i=1;
						$selected=$_POST['quizecheck'];
						//print_r($selected);
						//echo count($selected);
						$len=count($selected);
						echo "<br>";
						$Qid=array_keys($selected);
						#-------
						
						#print_r($selected);echo "<br>";
						$selected1 = array_values($selected);
						/*print_r($selected1);echo "<br>";
						print_r($selected1[0]);*/
						
					for ($j=0;$j<$len;$j++)
						{						
							$q="select Correct_ans from tb_question where subject_code='$scode' and Q_id='$Qid[$j]'";
							$query=mysqli_query($con,$q);
							print_r ($selected[$q]);
							$row=mysqli_fetch_array($query);
							//print_r($row['Correct_ans']);
							//print_r($selected1[$j]);
							$checked=$row['Correct_ans']== $selected1[$j];
							if($checked)
							{
								$result=$result+10;
							}
						}
						//echo $scode;
						$i++;
						
				
						?>
						<?php
						if($result<50)
						{
						   echo "<br>". "<b>you need to study more best luck for next time</b>";
						}
						elseif($result>80)
						{
							echo "<br>". "Congratulation....! best score ".$result;
						}
						?>
						
	
			<tr>
			
			<tr rowspan="">
			<th>Your TotalScore is</th>
			<td><?php echo $result;?></td></tr>
			</table></div>
			<?php
		}
		else
		{
			echo"<b><h3>You Are Not Attendding Any Question</b></h3>";
		}
	
	
	#insertion in tb_student
	
	$total_marks=$total_question*10;

	
	
	
	$query="insert into tb_exam_details(user_id,subject_code,total_question,Question_attened,total_marks,Obtained_marks,
	exam_start_time,exam_end_time)
	values('$user_id','$scode','$total_question','$count','$total_marks','$result','$start_time',now())";
	$sql=mysqli_query($con,$query);
	//$row=mysqli_fetch_array($sql);
	
	
	
	
	
	
	
	}
}
else{
	echo"<script>location.href='login.php'</script>";

}
	

	

?>
</div>
</div>

</body>
</html>