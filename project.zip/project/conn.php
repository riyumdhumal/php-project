<?php

$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);

if($con)
{
	//echo"connection successful";
	}
	else
	{
		echo"connection failed";
	}
	?>