<?php
include('conn.php');
//include('header1.php');
echo $scode=$_GET['id'];
 $scode=$_GET['id'];
?>


<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>

<body>
<div class="cointaner">
<div class="col-md-12 col-lg-12 col-sm-12">
<div class="panel panel-primary">
<div class="panel-heading text-center">
<h2 style={"color:black;"}><b>Welcome <?php session_start(); echo$_SESSION['name'];?> In Quize
<span class="Glyphicon glyphicon-king"> </span> &nbsp;&nbsp;World. </b> </h2>
</div></div>
<form method="POST" action="check.php">
<?php
error_reporting(0);
if(isset($_SESSION['name']))	
{

	include('conn.php');
	$q="SELECT Question,Q_id FROM tb_question where subject_code=845";
	$res=mysqli_query($con,$q);		
	while($row=mysqli_fetch_array($res))
	{
		echo $row['Q_id'];
		echo $row['Question'];
		$qid=$row['Q_id'];
		echo "<br>";	
		$q1="SELECT Q_id,Program,Correct_ans,Choice1,Choice2,Choice3,Choice4 FROM tb_question where Q_id='$qid'";
		$res1=mysqli_query($con,$q1);
		while($row1=mysqli_fetch_array($res1))
		{?>
			<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice1'];?>"><?php echo $row1['Choice1'];?><br>
			<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice2'];?>"><?php echo $row1['Choice2'];?><br>
			<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice3'];?>"><?php echo $row1['Choice3'];?><br>
			<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice4'];?>"><?php echo $row1['Choice4'];?><br>
		<?php }
	} 
 
}?>
</div>
</div>
</form>	
</body>
</html>