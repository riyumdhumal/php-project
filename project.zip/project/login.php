<?php
//echo$scode=$_GET['id'];

error_reporting("E_ALL");
//if(isset($_SESSION['user_id']))
if(isset($_SESSION['name']))
{
	print_r($_SESSION['name']);
	echo"<script>alert('You are already login')</script>";
	echo" you are already login";
	//header('location:test.php');
	//echo"<script>location.href='test.php'</script>";
} else
{					 	

?>

<html>

<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>

<body>
<style>
body{
   background-image:url('image/bg3.jpg');
   -webkit-background-size:cover;
  -moz-webkit-background-size:cover;
   background-size:cover;
   width:100%;
   height:100%;
	 
   
}
.pos{
	color:black;
	background-color:#f2faf4;
	margin-top:25%;
}
</style>

<form method="POST">
<div class="container">
<div class="col-md-12 col-lg-12">
<h1></h1>

<div class="col-md-6 offset-2">
	<div class="well pos ">

			<div class="panel panel-primary">
<div class="panel-heading">
<h1 style="color:red;font-style:arial;font-size:30;text-align:center">
<span class="glyphicon glyphicon-">&nbsp;<strong>Login</strong></span></h1>
</div></div>


			<div class="col-md-6-offset-2">
			<!--<label style="color:White">User_Type</label>-->
			<select name="user_type" class="form-control">
			<option value="0">Select user type </option>
			<option value="Admin">Admin</option>
			<option value="Teacher">Teacher</option>
			<option value="Student">Student</option>
			</select>
			</div><br>

			<div class="col-md-6-offset-2"><input type="name" name="name"  value="" class="form-control" 
			placeholder="Enter your name" required>
			</div><br><br>

			<!--<div class="col-md-6-offset-2"><input type="email" name="email"  value="" class="form-control" 
			placeholder="Enter your Email" required>
			</div><br><br>-->
			
			


			<div class="col-md-6-offset-2"><input type="Password" name="password" id="Password" value="" class="form-control" 
			placeholder="Enter your Password" required>
			</div><br><br>


			
            <div class="text-center">	
					 <button type="submit" name ="login" value ="login" class="btn btn-danger" >
					 <span class="glyphicon glyphicon-ok"></span> login
					</button>
					<!--<a href="dashboard.php" class="btn btn-info" role="button">login</a>-->
				</div><br>
					<h5 style="margin-left:70px;">If not registered?<a href="Regi.php">Register Here</a></b></h5>

			</div><br><br>

	</div>
</div>

</div>
</div>
</form>
</body>
</html>


<?php


$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);



if(isset($_POST['login']))
{
	session_start();
	$name=$_POST['name'];
	$password=$_POST['password'];
	$user_type=$_POST['user_type'];
	
	
	
	$q="select Name,Password,user_type,user_id from tb_user where Name='$name' and user_type='$user_type'and Password='$password'";
	$res=mysqli_query($con,$q);
	$row=mysqli_fetch_array($res);
	
		
			if($row["Name"]==$name && $row["user_type"]==$user_type && $row["Password"]==$password)
			{
				//echo"login success";
				echo $id=$row['user_id'];
				$r="insert into tb_login_details(user_id,login_time)values('$id',now())";
				$s=mysqli_query($con,$r);
				
				$_SESSION['name']=$row['Name'];
				$_SESSION['user_type']=$row['user_type'];
				$_SESSION['user_id']=$id;
				
				//print_r($_SESSION['name']);
				if($row['user_type']=='Student')
				{
					header('location:new.php');
				}
				
				elseif($row['user_type']=='Teacher')
				{
					header('location:new2.php');
				}
				elseif($row['user_type']=='Admin')
				{
					header('location:new3.php');
				}
				else
				{
					echo"select user type";
				}	
				
					
			}
			else
			{
				echo"could not match user_name and password";
			}
}
?>
<?php
}
?>
