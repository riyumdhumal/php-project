-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2020 at 10:29 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tb_question`
--

CREATE TABLE `tb_question` (
  `Q_id` int(11) NOT NULL,
  `Question` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Program` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Choice1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Choice2` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Choice3` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Choice4` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Correct_ans` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_question`
--

INSERT INTO `tb_question` (`Q_id`, `Question`, `Program`, `Choice1`, `Choice2`, `Choice3`, `Choice4`, `Correct_ans`) VALUES
(1, '1] who is the father of php?', '', 'Rasmus Lerdorf', 'Willam Makepice', 'Drek kolkevi', 'List Barely', 'Rasmus Lerdorf'),
(2, '2]which is incorrect declearation ?', '', '$3i;', '$i;', '$_ram;', '$dra3kl;', '$3i;'),
(3, '3]we can use__to comment a single line?', '', '#', '//', '/**/', 'All of aboove', 'All of aboove'),
(4, '4]php script should start with__', '', '1]&lt;?php ?', '2]php?>', '3]&lt;php>', '4]&lt;?php?>', '&lt;?php ?>'),
(5, '5]what will be following output?', '<?php\r\n$num=1;\r\n$num1=2;\r\nprint $num. \"+\" $num1;\r\n?>', '3', '1+2', '1.+.2', 'ERROR', '1+2'),
(6, '6]what will be following output?', '<?php\r\n$total=\" 25 students \";\r\n$more=\"10\";\r\n$total=$total+$more;\r\necho \"$total\";\r\n?>', 'Error', '35 student', '35', '25 student', '35'),
(7, '7]which of following is correct way of creationg an array?', '1)state[0]=\"karnataka\";\r\n2)$state[]=array(\"karnataka\");\r\n3)$state[]=\"karnataka\";\r\n4)$state=array(\"karnatka\");', '3) and 4)', '3)and1)', 'only1)', '2),3)&4)', '3) and 4)'),
(8, '8]which of the  function is used to sort array in descending order?', '', 'asort', 'sort', 'rsort', 'dsort', 'rsort'),
(9, '9]which of the following is concatenation operator in php? ', '', '1].(dot)', '2]&(Ampersand)', '3]+(plus)', '4]%(percentage)', '1].(dot)'),
(10, '10]what will be the output of following php code?', '<?php\r\n$state=array(\"karnataka\",\"Goa\", \"TamilNadhu\",\"AndhraPradesh\");\r\necho\" (arraysearch(\"Tamil Nadhu\",$state))\";\r\n?>', '1]true', '2]1', '3]False', '4]2', '4]2'),
(11, '11]what will be following output?', '<?php\r\n$number=array(\"4\",\"hello\",2);\r\necho(array_sum($number));\r\n?>', '1]4hello2', '2]2', '3]4', '4]6', '4]6');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `user_id` int(11) NOT NULL,
  `Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Gender` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Clg_Name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Mobile_No` int(255) NOT NULL,
  `Password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Reg_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`user_id`, `Name`, `Gender`, `Clg_Name`, `Email`, `Mobile_No`, `Password`, `Reg_Date`) VALUES
(1, 'mayuri', 'female', 'sspb', 'pankaj@gmail.com', 2147483647, 'user', '2020-05-09'),
(2, 'tanishka ', 'female', 'ndp', 'tanu@gmail.com', 2147483647, 'tanu', '2020-05-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_question`
--
ALTER TABLE `tb_question`
  ADD PRIMARY KEY (`Q_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tb_question`
--
ALTER TABLE `tb_question`
  MODIFY `Q_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
