<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body {
  margin: 0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: auto;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin:0px;
	
}
</style>
</head>
<body>
<div class="header">
<h4 class=""><b style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;Online Examination System
</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i   class='fa fa-fw fa-sign-out'> Sign-out</i> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user">&nbsp;&nbsp;user</i>
</button>

</h4>
</div>

<div class="sidebar">
  <a class="active" href="#home"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
  <a href="subject.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Add Subject</a>
  <a href="Quize.php"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Questions</a>
  <a href="#about"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
</div>

<div class="content">
  
</div>

</body>
</html>
