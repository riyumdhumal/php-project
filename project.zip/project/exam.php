

 <?php
 //include('subject.php');
 //echo$scode=$_GET['subject_code'];
 session_start();
$u_type=$_SESSION['user_type'];
$u_name=$_SESSION['name'];

?>
 



<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>

body {
  margin: 0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: auto;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin:0px;
	
}


.animateuse{
	animation:headanimate 0.5s infinite;
	
}
@keyframes headanimate{
	
	0%{color:red},
	10%{color:yellow},
	20%{color:blue},
	40%{color:green},
	50%{color:pink},
	60%{color:orange},
	80%{color:black},
	100%{color:brown}
	
}



</style>



</head>
<body>
<div class="header" id="">
<h4 class=" text-success "><b  style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;<i class="animateuse">Online Examination System
</i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i   class='fa fa-fw fa-sign-out'><a href="logout.php"> Sign-out</a></i> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user">&nbsp;&nbsp;</i><?php echo $u_name."(".$u_type.")";?>
</button>

</h4>
</div>

<div class="sidebar">
  <a class="active" href="new.php"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
  <a href="exam.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Exam</a>
  <a href="#"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Subject</a>
  <a href="#"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
</div>
	<div class="content">
	<div class="container">
	<div class="col-md-8-offset-2" style="margin-top:60px;">
	
	<?php
	include('conn.php');
	$q="select * from tb_subject";
	$res=mysqli_query($con,$q);
	?>

	
	<table class="table table-striped">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Topic</th>
        <th>Total Quetion</th>
        <th>Marks</th>
        <th> </th>
      </tr>
    </thead>
    <tbody>
	<?php
	while($row=mysqli_fetch_array($res))
	{?>
		<tr>
        <td><?php echo $row['subject_code']; ?></td>
        <td><?php echo $row['subject_name'];?></td>
        <td><?php echo $row['total_question']; ?></td>
        <td><?php echo $row['marks']; ?></td>
       
        <td><button class="success"><a href="Test_DB.php?id=<?php echo $row['subject_code'];?>">Start</a></button></td>

      
	  </tr>
	   <?php
	
	}
    ?>  
     
    </tbody>
  </table>
  <br>
  
</div>
</div>



		

</body>
</html>
