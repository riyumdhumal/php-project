<html>

<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>

<body>
<style>
/* 
body{
   background-image:url('image/bg3.jpg');
   -webkit-background-size:cover;
  -moz-webkit-background-size:cover;
   background-size:cover;
   width:100%;
   height:100%;
   */
	 
   
}
.pos{
	color:black;
	background-color:#333333;
	margin-top:30px;
}
</style>

<form method="POST" style="margin-top:50px;">
<div class="container">
<div class="col-md-12 col-lg-12">







<div class="col-md-6 offset-2">
	<div class="well pos ">
			
			
			<div class="panel panel-primary">
<div class="panel-heading">
<h1 style="color:white;font-style:arial;font-size:24;text-align:center">
<span class="glyphicon glyphicon-">&nbsp;<strong>Add Subject</strong></span></h1>
</div>
</div>
			
			<div class="col-md-6-offset-2"><input type="text" name="subject_code" id= value="" class="form-control" 
			placeholder="Enter subject code" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="subject_name"  value="" class="form-control" 
			placeholder="Enter subject name" required>
			</div><br>
			
			
			
			<div class="col-md-6-offset-2"><input type="text" name="total_question" id="" value="" class="form-control" 
			placeholder="Enter total no of questions" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="marks" id="" value="" class="form-control" 
			placeholder="Enter Marks" required>
			</div><br>
			
			
			
		<!--	<div class="col-md-6-offset-2" class="form-control">
			<label style="color:white">Correct answer</label>
			<select name="ans">
			<option value="">select answer</option>
			<option value="ch1">choice_1</option>
			<option value="ch2">choice_2</option>
			<option value="ch3">choice_3</option>
			<option value="ch4">choice_4</option>
			</select>
			</div><br>-->
			
		
			
            <div class="text-justify" style="margin-left:150px">	
					 <button type="submit" name="submit" value="submit" class="btn btn-danger" >
					 <span class="glyphicon glyphicon-"></span> submit
					</button>
					
				
			</div><br><br>


	</div>
</div>


</div>
</div>
</form>
</body>
</html>
<?php
$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);

if($con)
{
	
	
if(isset($_POST['submit']))
{
echo"connection successfull.....!";
	
	$subject_code=$_POST['subject_code'];
	$subject_name=$_POST['subject_name'];
	$total_question=$_POST['total_question'];
	$marks=$_POST['marks'];
	
	
	$query="insert into tb_subject(subject_code,subject_name,total_question,marks)
	values('$subject_code','$subject_name','$total_question','$marks')";
	$sql=mysqli_query($con,$query);
	//$row=mysqli_fetch_array($sql);
	
}
}
?>