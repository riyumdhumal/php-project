<?php
include('conn.php');

?>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>

<body>
<div class="cointaner">
<div class="col-md-12 col-lg-12 col-sm-12">
<style>
.demo{
	background-color:#c9c5b9;
	height:55px;
	font-size:30px important!;
	padding-top:5px;
	color:white;
}
body{
   background-image:url('image/bg3.jpg');
   -webkit-background-size:cover;
  -moz-webkit-background-size:cover;
   background-size:cover;
   width:100%;
   height:100%;
	 
   
}
</style>
<h4 class="demo"><b style="padding-top:10px !important;"> &nbsp;&nbsp;
<i class='fas fa-desktop'></i> &nbsp;&nbsp;&nbsp;Online Examination System
</b>
<span class="glyphicon glyphicon-user" style="margin-left:70%;">
 <?php session_start(); echo$_SESSION['name'];?> </span>
 <!--<span class="glyphicon glyphicon-log-out" style="margin-right:-75%;"></span> 
-->
<a href="logout.php"  class="primary" style="margin-left:90%;display:inline"><span 
class="glyphicon glyphicon-log-out"></span> Log out
</a>
</h4>
</div>
</div>


</body>
</html>