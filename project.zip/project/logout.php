<?php
session_start();
include('conn.php');
$u_id = $_SESSION['user_id'];
//echo $u_id;
$q="update tb_login_details SET logout_time=now() where user_id='$u_id'";
$s=mysqli_query($con,$q);

session_destroy();
unset($name);//remove the value of variable
echo "<script>location.href='login.php'</script>";
?>