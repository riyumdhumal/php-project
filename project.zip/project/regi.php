<html>

<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>

<body>
<style>
body{
   background-image:url('image/bg3.jpg');
   -webkit-background-size:cover;
  -moz-webkit-background-size:cover;
   background-size:cover;
   width:100%;
   height:100%;
	 
   
}
.pos{
	color:black;
	background-color:#333333;
	
}
</style>

<form method="POST">
<div class="container">
<div class="col-md-12 col-lg-12">
<h1>Test Your Skill</h1>

<div class="col-md-6 offset-2">

<div class="panel panel-primary">
<div class="panel-heading">
<h1 style="color:red;font-style:arial;font-size:24;text-align:center">
<span class="glyphicon glyphicon-home">&nbsp;<strong>Registration Form</strong></span></h1>
</div></div>


	<div class="well pos ">


			<div class="col-md-6-offset-2">
			<!--<label style="color:White">User_Type</label>-->
			<select name="user_type" class="form-control">
			<option value="0">Select user type </option>
			<option value="Admin">Admin</option>
			<option value="Teacher">Teacher</option>
			<option value="Student">Student</option>
			</select>
			</div><br>

			<div class="col-md-6-offset-2"><input type="text" name="name" id="" value="" class="form-control" 
			placeholder="Enter your Name" required>
			</div><br><br>
			
			
			<div class="col-md-4-offset-3 well">select your gender<br>

			<div class="col-md-2" class="form-control">
			<label>Male</label><input type="radio" name="gender" id="" value="male" class="form-control" 
			placeholder="" required></div>
			
			<div class="col-md-2">
			<label>Female</label><input type="radio" name="gender" id="" value="female" class="form-control" 
			placeholder="" required></div></div>
			<br><br>



			<div class="col-md-6-offset-2"><input type="text" name="cname" id="" value="" class="form-control" 
			placeholder="Enter your College Name" required>
			</div><br><br>
			
			<div class="col-md-6-offset-2"><input type="email" name="email"  value="" class="form-control" 
			placeholder="Enter your Email" required>
			</div><br><br>


			<div class="col-md-6-offset-2"><input type="number" name="mbl_no" id="" value="" class="form-control" 
			placeholder="Enter your Mobile Number" required>
			</div><br><br>

			<div class="col-md-6-offset-2"><input type="Password" name="password" id="Password" value="" class="form-control" 
			placeholder="Enter your Password" required>
			</div><br><br>


			
            <div class="text-justify" style="margin-left:150px">	
					 <button type="submit" name ="submit" value ="submit" class="btn btn-danger" >
					 <span class="glyphicon glyphicon-ok"></span> save
					</button>
					<a href="login.php" class="btn btn-info" role="button">login</a>
				</div><br><br>
				
			</div><br><br>


	</div>
</div>

</div>
</div>
</form>
</body>
</html>
<?php


$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);

if($con)
{
	
	
if(isset($_POST['submit']))
{
echo"connection successfull.....!";
	
session_start();
$_SESSION['name']=$_POST['name'];

	$name=$_POST['name'];
	$user_type=$_POST['user_type'];
	$gender=$_POST['gender'];
	$cname=$_POST['cname'];
	$mbl_no=$_POST['mbl_no'];
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	$query="insert into tb_user(Name,user_type,Gender, Clg_Name,Email,Mobile_No,Password,Reg_Date)
	values('$name','$user_type','$gender','$cname','$email','$mbl_no','$password',now())";
	$sql=mysqli_query($con,$query);
	
}
}
?>

