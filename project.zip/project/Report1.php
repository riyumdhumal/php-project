<!DOCTYPE html>
<?php
session_start();
$u_type=$_SESSION['user_type'];
$u_name=$_SESSION['name'];

?>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<script src='https://kit.fontawesome.com/a076d05399.js'></script>


<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body {
  margin:0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: auto;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin:0px;
	
}


</style>
</script>

<script type="text/javascript">

var mymenu=new drilldownmenu({
	menuid: 'drillmenu1',
	menuheight: 'auto',
	breadcrumbid: 'drillcrumb',
	persist: {enable: true, overrideselectedul: true}
})

</script>
</head>
<body>
<div class="header">
<h4 class=""><b style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;Online Examination System
</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
 <span class="glyphicon glyphicon-log-out"><a href="logout.php"> Sign-out</a></span> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user">&nbsp;&nbsp;</i><?php echo $u_name."(".$u_type.")";?>
</button>

</h4>
</div>

<div class="sidebar">
  <a class="active" href="#home"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
   <a href="subject.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Add Subject</a>
  <a href="Quize.php"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Add Questions</a>
  <a href="Viewque.php"><i style="font-size:30px;" class="fas fa-question-circle"></i><br>View Questions</a>
 <a href="Report1.php"><i style="font-size:30px;" class="material-icons">&#xe1b8;</i><br>Reports</a>
  <a href="#about"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
 
</div>


<div class="content" style="margin-top:30px;width:60%;">
<form type="" method="POST">
<?php

include('conn.php');

$query="select subject_code,subject_name from tb_subject";
	$res=mysqli_query($con,$query);
	?>
	
  <select name="subjects"  required>
  <option value="0">Select subject name</option>
  <option value="all">All subject</option>
  
  <?php
	while($row=mysqli_fetch_array($res))
	{
		$sub_name=$row['subject_name'];
		$sub_code=$row['subject_code'];
		
		echo "<option value='$sub_code'>$sub_name</option>";
	} ?>
  </select>
  <button type="submit" name="show" value="show">View result</button>

<?php
	if(isset($_POST['show']))
	{
		$sub_code=$_POST['subjects'];
		
		$q="select Name,subject_name,e.total_question,Question_attened,total_marks,obtained_marks,(obtained_marks/total_marks)*100 as percent ,DENSE_RANK() OVER( ORDER BY (obtained_marks/total_marks)*100 desc)as ranking from tb_exam_details e 
		inner join tb_user u on e.user_id=u.user_id 
		inner join tb_subject s on e.subject_code=s.subject_code where s.subject_code='$sub_code' ";
		
		
		$q1="select Name,subject_name,e.total_question,Question_attened,total_marks,obtained_marks,(obtained_marks/total_marks)*100 as percent ,DENSE_RANK() OVER( ORDER BY (obtained_marks/total_marks)*100 desc)as ranking from tb_exam_details e 
		inner join tb_user u on e.user_id=u.user_id 
		inner join tb_subject s on e.subject_code=s.subject_code";
		
		if($sub_code=="all")
		{	
			$res=mysqli_query($con,$q1);
		}
		else
		{
			$res=mysqli_query($con,$q);
		}
		?>
		<table class="table table-striped">
		<thead>
		  <tr>
			<th>Student Name</th>
			<th>Subject Name</th>
			<th>Total Question</th>
			<th>Question Attened</th>
			<th>Total Marks</th>
			<th>Obtained Marks</th>
			<th>Percentage</th>
			<th>Rank</th>
			
			<th> </th>
		  </tr>
		</thead>
		<tbody>
		<?php
		while($row=mysqli_fetch_array($res))
		{?>
			<tr>
			<td><?php echo $row['Name']; ?></td>
			<td><?php echo $row['subject_name'];?></td>
			<td><?php echo $row['total_question']; ?></td>
			<td><?php echo $row['Question_attened']; ?></td>
			<td><?php echo $row['total_marks']; ?></td>
			<td><?php echo $row['obtained_marks']; ?></td>
			<td><?php echo $row['percent']; ?></td>
			<td><?php echo $row['ranking']; ?></td>
		   
			<!--<td><button class="success"><a href="Test_DB.php?id=<?php/* echo $row['subject_code'];*/?>">Start</a></button></td>-->
		  
		  </tr>
		   <?php
		
	    }
	}
    ?>  
		



	
     
</form>  
</div>

</body>
</html>
