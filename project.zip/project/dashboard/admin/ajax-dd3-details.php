<!doctype html public "-//w3c//dtd html 3.2//en">
<html>
<head>
<title></title>
<META NAME="DESCRIPTION" CONTENT="">
<META NAME="KEYWORDS" CONTENT="">
</head>

<body>
<?Php
echo "Country : $_POST[country]<br>
State : $_POST[state]<br>
City : $_POST[city]<br>
<br><br><br>
Return to <a href=ajax-dd3.php>Drop down list</a>
";
?>

</body>
</html>
