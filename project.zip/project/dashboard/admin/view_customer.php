<?php 

include('header.php');
include('sidebar.php');
include('../connection.php');

?>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {

        $('#example').DataTable();
    });
</script>
<div id="page-wrapper">
  <div class="graphs">
    <h3 class="blank1">View Customer <button style="float:right" class="btn btn-success" onclick="window.location.href = 'add_customer.php';">Add Customer</button></h3>

    <div class="xs tabls">
      <div class="bs-example4" data-example-id="contextual-table" style="overflow-y: scroll;">
        <table class="table table-hover" id="example" class="display" width="100%" cellspacing="0">
          <thead>
            <tr>
            
            <th>Id</th>
            <th>Name</th>
              <th>Address</th>
              <th>Phone</th>
              <th>Mobile</th>
              <th>Email</th>
              <th>Password</th>
              <th>WEB</th>
              <th>PAN</th>
              <th>GST</th>
              <th>State</th>
              <th>Branch</th>
			  <th>Contact</th>
              <th>Status</th>
             

            </tr>
          </thead>
          <tbody>
          <?php 
            $sql="Select * from customer";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['id'];?></td>
			<td><?php echo $ros['name'];?></td>
            <td><?php echo $ros['address'];?></td>
            <td><?php echo $ros['phone'];?></td>
            <td><?php echo $ros['mobile'];?></td>
            <td><?php echo $ros['email'];?></td>
            <td><?php echo $ros['password'];?></td>
             <td><?php echo $ros['web'];?></td>
            <td><?php echo $ros['pan'];?></td>
            <td><?php echo $ros['gst'];?></td>
            <td><?php echo $ros['state'];?></td>
			<td><?php echo $ros['branch'];?></td>
			<td><?php echo $ros['contact'];?></td>
			<td><?php echo $ros['status'];?></td>
            
            
            

          </tr>
          <?php

        }
        ?>
       

          </tbody>


        </table>
      </div>
    </div>
  </div>
</div>

<?php

include('footer.php');


if(isset($_REQUEST['deleteid']))
{

$id=$_REQUEST['deleteid'];

$sql="DELETE FROM `customer` WHERE `customer`.`id` = '$id'";


    $res=mysqli_query($conn,$sql);

    if($res)
    {
      echo"<script>alert('Delete sucessfully');window.location='view_customer.php'</script>";
    }
    else
    {
      echo"<script>alert('data Delete error');window.location='view_customer.php'</script>";

    }


}
?>
