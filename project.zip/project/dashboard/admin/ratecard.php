<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>

<!--
//index.php
!-->

<html>  
    <head>  
        <title>Rate Card</title>  
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<link rel="stylesheet" href="auto.css" type="text/css" /> 
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		<script type="text/javascript">
$(function() {
	
	//autocomplete
	$(".auto").autocomplete({
		source: "search.php",
		minLength: 1
	});				

});
</script>
 <script>
function getCountry(val) {
$.ajax({
    type: "POST",
    url: "get_country.php",
    data:'region_id='+val,

   success: function(data){
    $("#country-list").html(data);
  }
  });
  }

  function selectRegion(val) {
  $("#search-box").val(val); 
  $("#suggesstion-box").hide();
  }
  </script>
    </head>  
    <body>  
        <div class="container">
            <div id="page-wrapper">
            <h3 class="blank1"> Add Rate Card Details <button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_courier.php';">View Card Details</button></h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
			<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				
				<div class="form-group">
						<form class="form-horizontal" action="" method="post" id="user_form" enctype="multipart/form-data">
							<div class="col-sm-3">
								<input type='text' name='customer_name' class="auto form-control form-control1" placeholder="Serach Customer Name">  
								
							</div>
							
							
							
							<div class="col-sm-2">
								<select class="form-control1" id="sel1" name="courier_name" >
							<option>select courier name</option>
								<?php
								$sql="Select * from courier";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						    
							
							<div class="col-sm-2">
							 <select class="form-control1" id="sel1" name="mode">
							     <option value="">-Mode-</option>
   									 <option value="Standard">Standard</option>
									 <option value="Express">Express</option>
									 <option value="Surface">Surface Cargo</option>
									 <option value="Air">Air Cargo</option>
									 <option value="Priority">Priority</option>
									 
							</select>
							</div>
							<div class="col-sm-2">
								<select class="form-control1" id="sel1" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							</div>
						    <div class="col-sm-2">
							 <select class="form-control1" id="sel1" name="dox">
							     <option value="">-DOX/NDOX-</option>
   									 <option value="DOX">DOX</option>
									 <option value="NDOX">NON-DOX</option>
									 
									 
							</select>
							</div>
							</div>
							
							</div>
							</div>
							</div>
			<div align="right" style="margin-bottom:5px;">
				<button type="button" name="add" id="add" class="btn btn-success btn-xs">Add</button>
			</div>
			
				<div class="table-responsive">
					<table class="table table-striped table-bordered" id="user_data">
						<tr>
							<th>Quantity</th>
							<th>Rate</th>
							<th>Details</th>
							<th>Remove</th>
						</tr>
					</table>
				</div>
				<div align="center">
					<input type="submit" name="insert" id="insert" class="btn btn-primary" value="Insert" />
				</div>
			</form>

			<br />
		</div>
		<div id="user_dialog" title="Add Data">
			<div class="form-group">
				<label>Quanity</label>
				<input type="text" name="first_name" id="first_name" class="form-control" />
				<span id="error_first_name" class="text-danger"></span>
			</div>
			<div class="form-group">
				<label>Rate</label>
				<input type="text" name="last_name" id="last_name" class="form-control" />
				<span id="error_last_name" class="text-danger"></span>
			</div>
			<div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<button type="button" name="save" id="save" class="btn btn-info">Save</button>
			</div>
		</div>
		<div id="action_alert" title="Action">

		</div>
    </body>  
</html>  




<script>  
$(document).ready(function(){ 
	
	var count = 0;

	$('#user_dialog').dialog({
		autoOpen:false,
		width:400
	});

	$('#add').click(function(){
		$('#user_dialog').dialog('option', 'title', 'Add Data');
		$('#first_name').val('');
		$('#last_name').val('');
		$('#error_first_name').text('');
		$('#error_last_name').text('');
		$('#first_name').css('border-color', '');
		$('#last_name').css('border-color', '');
		$('#save').text('Save');
		$('#user_dialog').dialog('open');
	});

	$('#save').click(function(){
		var error_first_name = '';
		var error_last_name = '';
		var first_name = '';
		var last_name = '';
		if($('#first_name').val() == '')
		{
			error_first_name = 'First Name is required';
			$('#error_first_name').text(error_first_name);
			$('#first_name').css('border-color', '#cc0000');
			first_name = '';
		}
		else
		{
			error_first_name = '';
			$('#error_first_name').text(error_first_name);
			$('#first_name').css('border-color', '');
			first_name = $('#first_name').val();
		}	
		if($('#last_name').val() == '')
		{
			error_last_name = 'Last Name is required';
			$('#error_last_name').text(error_last_name);
			$('#last_name').css('border-color', '#cc0000');
			last_name = '';
		}
		else
		{
			error_last_name = '';
			$('#error_last_name').text(error_last_name);
			$('#last_name').css('border-color', '');
			last_name = $('#last_name').val();
		}
		if(error_first_name != '' || error_last_name != '')
		{
			return false;
		}
		else
		{
			if($('#save').text() == 'Save')
			{
				count = count + 1;
				output = '<tr id="row_'+count+'">';
				output += '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+count+'" class="first_name" value="'+first_name+'" /></td>';
				output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+count+'" value="'+last_name+'" /></td>';
				output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+count+'">View</button></td>';
				output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+count+'">Remove</button></td>';
				output += '</tr>';
				$('#user_data').append(output);
			}
			else
			{
				var row_id = $('#hidden_row_id').val();
				output = '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+row_id+'" class="first_name" value="'+first_name+'" /></td>';
				output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+row_id+'" value="'+last_name+'" /></td>';
				output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+row_id+'">View</button></td>';
				output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+row_id+'">Remove</button></td>';
				$('#row_'+row_id+'').html(output);
			}

			$('#user_dialog').dialog('close');
		}
	});

	$(document).on('click', '.view_details', function(){
		var row_id = $(this).attr("id");
		var first_name = $('#first_name'+row_id+'').val();
		var last_name = $('#last_name'+row_id+'').val();
		$('#first_name').val(first_name);
		$('#last_name').val(last_name);
		$('#save').text('Edit');
		$('#hidden_row_id').val(row_id);
		$('#user_dialog').dialog('option', 'title', 'Edit Data');
		$('#user_dialog').dialog('open');
	});

	$(document).on('click', '.remove_details', function(){
		var row_id = $(this).attr("id");
		if(confirm("Are you sure you want to remove this row data?"))
		{
			$('#row_'+row_id+'').remove();
		}
		else
		{
			return false;
		}
	});

	$('#action_alert').dialog({
		autoOpen:false
	});

	$('#user_form').on('submit', function(event){
		event.preventDefault();
		var count_data = 0;
		$('.first_name').each(function(){
			count_data = count_data + 1;
		});
		if(count_data > 0)
		{
			var form_data = $(this).serialize();
			$.ajax({
				url:"insert.php",
				method:"POST",
				data:form_data,
				success:function(data)
				{
					$('#user_data').find("tr:gt(0)").remove();
					$('#action_alert').html('<p>Data Inserted Successfully</p>');
					$('#action_alert').dialog('open');
				}
			})
		}
		else
		{
			$('#action_alert').html('<p>Please Add atleast one data</p>');
			$('#action_alert').dialog('open');
		}
	});
	
});  
</script>