<?php
$servername = "103.50.160.62";
$username = "quickqpt_root";
$password = "helpdesk@123";
$dbname = "quickqpt_courier";
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("Connection failed: " . mysqli_connect_error());
if (mysqli_connect_errno()) {
printf("Connect failed: %s\n", mysqli_connect_error());
exit();
}
?>