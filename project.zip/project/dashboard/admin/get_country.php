<?php
    require_once 'ajaxpro.php';


    if(!empty($_REQUEST["region_id"])) {

    $query ="SELECT * FROM customer WHERE name =" . "'" . $_POST["region_id"] ."'";
    //echo $query ="SELECT * FROM geo WHERE Region =" . "'" . $_POST["region_id"] ."'";

    $result = mysqli_query($conn, $query);
?>
    

<?php
    while($row2=mysqli_fetch_assoc($result)){

        //var_dump($row2);
        if($bul2[$row2['Country']] != true && $row2['Country'] != 'Country' || 1)        { ?>
            <option value="<?php echo $row2['branch']; ?>"><?php echo     $row2['branch']; ?>  </option>
 <?php  
         $bul2[$row2['Country']] = true;
         }
     }
    }
?>