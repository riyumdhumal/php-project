<?Php
/////// Update your database login details here /////
$dbhost_name = "103.50.160.62"; // Your host name 
$database = "quickqpt_courier";       // Your database name
$username = "quickqpt_root";            // Your login userid 
$password = "helpdesk@123";            // Your password 
//////// End of database details of your server //////

//////// Do not Edit below /////////
try {
$dbo = new PDO('mysql:host='.$dbhost_name.';dbname='.$database, $username, $password);
} catch (PDOException $e) {
print "Error!: " . $e->getMessage() . "<br/>";
die();
}
?> 