<?php

$conn=mysqli_connect("103.50.160.62","quickqpt_root","helpdesk@123","quickqpt_courier");

if(!$conn)
{
	echo 'could not connect'.mysqli_error();
}

?>