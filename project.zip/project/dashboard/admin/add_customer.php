<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<div id="page-wrapper">
	<div class="graphs">
		<h3 class="blank1"> Add Customer  Details <button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_customer.php';">View Customer</button></h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Customer Name:</label>
							<div class="col-sm-8">
					<input type="text" class="form-control1" name="name" placeholder="Customer Name" required="" id="dearname">
							</div>
						</div>

							<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Customer Address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="address" placeholder="Enter Customer addrerss" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Phone:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="phone" placeholder="Enter phone" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Mobile:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="mobile" placeholder="Enter mobile" required="" id="dearname">
							</div>
						</div>

							<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Material Descrition:</label>
							<div class="col-sm-8">
							 <select class="form-control" id="sel1" name="material_descrition">
   									 <option value="document">document</option>
							</select>
							</div>
						</div>-->
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Email</label>
							<div class="col-sm-3">
								<input type="email" class="form-control1" name="email" placeholder="Enter email" required="" >
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Password</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="password" placeholder="Enter password" required="" id="dearname">
							</div>
						</div>
						
						
						
						
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Web</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="web" placeholder="Enter web address" required="" >
							</div>
						
							<label for="focusedinput" class="col-sm-1 control-label">PAN</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="pan" placeholder="Enter PAN" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-1 control-label">GST</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="gst" placeholder="Enter GST" required="" >
							</div>
						</div>
						
						
						
						
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">State Code:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="state" placeholder="Enter State Code" required="" id="dearname">
							</div>
							<label for="focusedinput" class="col-sm-2 control-label">Branch:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="branch" placeholder="Enter Branch" required="" id="dearname">
							</div>
						
							
							</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Contact Person:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="judidial" placeholder="Enter Contact Person" required="" >
							</div>						
							<label for="focusedinput" class="col-sm-2 control-label">Status:</label>
							<div class="col-sm-3">
							 <select class="form-control1" id="sel1" name="status">
   									 <option value="U">U - In use</option>
									 <option value="U">O - Obsolete</option>
									 
							</select>
							</div>
						</div>
						
						
						

							<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Category</label>
							<div class="col-sm-8">
							<select class="form-control" id="sel1" name="Category">
   									 <option value="speed">speed</option>
   									 <option value="spical">spical</option>
   									 <option value="normal">normal</option>
							</select>
							</div>
						</div>
					
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Corporate id</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Corporateid" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Shipping charge</label>
							<div class="col-sm-8">
								<input type="number" class="form-control1" name="shappingcharge" placeholder="Enter Shipping charge" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch Id :</label>
							<div class="col-sm-8">
								<select class="form-control" id="sel1" name="branchid" >
							<option>select</option>
								<?php
								$sql="Select * from branch";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['branch_id'];?>"><?php echo $ros['branch_id'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Date of booking :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="dateofbooking" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"> book at Branch :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="booked_at_branch" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch location :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="branchlocation" placeholder="Enter branch location" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">destination :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="destination" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver name :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="reciver_name" placeholder="Enter Reciver name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="rciveraddress" placeholder="Enter Reciver Address" required="">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Phone no :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Reciver_phone_no" placeholder="Enter Reciver Phone no" required="" >
							</div>
						</div>-->



						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"></label>
							<div class="col-sm-8">
								<button type="Submit" class="btn btn-success" name="Customer">Submit</button>
								<a href=""><button type="button" class="btn btn-danger">Cancel</button></a>
							</div>
						</div>

					</form>
				</div>
			</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>


	<?php 
	include('footer.php');

	if(isset($_REQUEST['Customer']))
	{

$name=$_REQUEST['name'];
$address=$_REQUEST['address'];
$phone=$_REQUEST['phone'];
$mobile=$_REQUEST['mobile'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$web=$_REQUEST['web'];
$pan=$_REQUEST['pan'];
$gst=$_REQUEST['gst'];
$state=$_REQUEST['state'];
$branch=$_REQUEST['branch'];
$contact=$_REQUEST['contact'];
$status=$_REQUEST['status'];
date_default_timezone_set("Asia/Calcutta");
$date=date('Y-m-d h:i:s'); 
$ccn="Book".time();
$bookingid="BOOK".time();
		


		$sql="INSERT INTO `customer` (`datetime`, `name`, `address`, `phone`, `mobile`, `email`, `password`, `web`, `pan`, `gst`, `state`, `branch`, `contact`, `status`) VALUES 
		('$date', '$name', '$address', '$phone', '$mobile', '$email', '$password', '$web', '$pan', '$gst', '$state', '$branch', '$contact', '$status')";

		$res=mysqli_query($conn,$sql);

		if($res)
		{
			echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Customer Added Successfully",
				icon: "success",
				button: "View Customers",
				}).then(function () {
				window.location.href = "view_customer.php"});
				</script>' ;
		}
		else
		{
			echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Adding Customer. Please contact System Administrator",
				icon: "error",
				button: "View Customers",
				}).then(function () {
				window.location.href = "add_customer.php"});
				</script>' ;

		}

	}
	?>


