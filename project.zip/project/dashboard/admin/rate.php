<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<link rel="stylesheet" href="auto.css" type="text/css" /> 
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script type="text/javascript">
$(function() {
	
	//autocomplete
	$(".auto").autocomplete({
		source: "search.php",
		minLength: 1
	});				

});
</script>
 <script>
function getCountry(val) {
$.ajax({
    type: "POST",
    url: "get_country.php",
    data:'region_id='+val,

   success: function(data){
    $("#country-list").html(data);
  }
  });
  }

  function selectRegion(val) {
  $("#search-box").val(val); 
  $("#suggesstion-box").hide();
  }
  </script>
<div id="page-wrapper">
	<div class="graphs">
		<h3 class="blank1"> Add Rate Card Details <button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_rate.php';">View Rate Card Details</button></h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<!--<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				<div class="form-group">
						
							<div class="col-sm-3">
								<input type='text' name='customer_name' class="auto form-control form-control1" placeholder="Serach Customer Name">  
								
							</div>
							
							
							
							<div class="col-sm-2">
								<select class="form-control1" id="sel1" name="courier_name" >
							<option>select courier name</option>
								<?php
								$sql="Select * from courier";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						    
							
							<div class="col-sm-2">
							 <select class="form-control1" id="sel1" name="mode">
							     <option value="">-Mode-</option>
   									 <option value="Standard">Standard</option>
									 <option value="Express">Express</option>
									 <option value="Surface">Surface Cargo</option>
									 <option value="Air">Air Cargo</option>
									 <option value="Priority">Priority</option>
									 
							</select>
							</div>
							<div class="col-sm-2">
								<select class="form-control1" id="location1" name="location1">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							</div>
						
							</div>-->
						</form>
						

<html>  
   
    <body>  
        <div class="container">
			
			<div align="right" style="margin-bottom:5px;">
				
			</div>
			
			<form method="post" id="user_form">
				<div class="table-responsive">
					<table class="table table-striped table-bordered" id="user_data">
					    <tr>
					        <td>
					           <input type='text' name='customer_name' class="auto form-control form-control1" placeholder="Serach Customer Name"> 
					        </td>
					        <td>
					          <select class="form-control1" id="sel1" name="courier_name" >
							<option>select courier name</option>
								<?php
								$sql="Select * from courier";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>  
					        </td>
					        <td><select  class="form-control1" id="selectbox">
							     <option value="">-Mode-</option>
   								

  <option value="#myModal1">
    Standard
  </option>

  <option value="#myModal2">
    Express
  </option>

  <option value="#myModal3">
    Surface Cargo
  </option>
  <option value="#myModal4">
    Air Cargo
  </option>

  <option value="#myModal5">
    Priority
  </option>
							</select></td>
					        
					        
							<td colspan="2">
        <input type="file" name="file" id="file" size="150">
        <p class="help-block">Only CSV File Import.</p>
        
       </td><td>
        
							    
								<button type="Submit" class="btn btn-success" name="submit">File Upload</button>
							
							</td>
							
							</tr>
							<tr><span id="error_location" class="text-danger"></span></tr>
						<tr>
							<th>Location</th>
							<th>Dox / N-Dox</th>
							<th>0.100</th>
							<th>0.250</th>
							<th>0.500</th>
							<th>Additional</th>
						</tr>
						<?php 
            $sql="Select * from trate";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['location'];?></td>
			 <td><?php echo $ros['dndox'];?></td>
			 <td><?php echo $ros['field1'];?></td>
			 <td><?php echo $ros['field2'];?></td>
			 <td><?php echo $ros['field3'];?></td>
			 <td><?php echo $ros['field4'];?></td>
           </tr>
          <?php
            
        }
        ?>
					</table>
				</div>
				<div align="center">
					<input type="submit" name="insert" id="insert" class="btn btn-primary" value="Insert" />
				</div>
			</form>

			<br />
		</div>
		<div id="user_dialog" title="Add Data">
			<div class="form-group">
				<label>Quanity</label>
				<input type="text" name="first_name" id="first_name" class="form-control1" />
				<span id="error_first_name" class="text-danger"></span>
			</div>
			<div class="form-group">
				<label>Rate</label>
				<input type="text" name="last_name" id="last_name" class="form-control1" />
				<span id="error_last_name" class="text-danger"></span>
			</div>
			<div class="form-group">
				<label>DOX / N-DOX</label>
				<select class="form-control1" id="dox" name="dox">
							     <option value="">--</option>
   									 <option value="DOX">DOX</option>
									 <option value="NDOX">NON-DOX</option>
									 
									 
							</select>
				<span id="error_dox" class="text-danger"></span>
			</div>
			<div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<button type="button" name="save" id="save" class="btn btn-info">Save</button>
			</div>
		</div>
		
		
		<div id="action_alert" title="Action">

		</div>
    </body>  
</html>  



<div id="myModal1" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Standard</h4>
      </div>
      <form action="" method="post">
      <div class="modal-body info">
                                    <select class="form-control1" id="location" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							<select class="form-control1" name="dndox">
							<option value="">DOX / N-DOX</option>
                                    <option value="DOX">DOX</option>
                                    <option value="NDOX">N-DOX</option>
                                       
							</select>
        
      </div>
      <table align="center">
          <tr>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
          </tr>
          <tr>
              <td><input type="text" name="head1" value="" style="width:75px"></td>
              <td><input type="text" name="head2" value="" style="width:75px"></td>
              <td><input type="text" name="head3" value="" style="width:75px"></td>
              <td><input type="text" name="head4" value="" style="width:75px"></td>
          </tr>
          <tr>
              <td><input type="text" name="field1" value="" style="width:75px"></td>
              <td><input type="text" name="field2" value="" style="width:75px"></td>
              <td><input type="text" name="field3" value="" style="width:75px"></td>
              <td><input type="text" name="field4" value="" style="width:75px"></td>
          </tr>
      </table>
      <div class="modal-footer addHEIGHT">
      </div>
      <div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<input type="submit" name="save" value="save" class="btn btn-info">
			</div>
    </div>
    </form>
  </div>
</div>
<?php 
	

	if(isset($_POST['save']))
	{

$location=$_POST['location'];
$dndox=$_POST['dndox'];
$field1=$_POST['field1'];
$field2=$_POST['field2'];
$field3=$_POST['field3'];
$field4=$_POST['field4'];
date_default_timezone_set("Asia/Calcutta");
$date=date('Y-m-d h:i:s'); 

		


		$sql="INSERT INTO `trate` (`datetime`, `location`, `dndox`, `field1`, `field2`, `field3`, `field4`) VALUES 
		('$date', '$location', '$dndox', '$field1', '$field2', '$field3', '$field4')";

		$res=mysqli_query($conn,$sql);

		if($res)
		{
			echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Courier Added Successfully",
				icon: "success",
				button: "View Courier",
				}).then(function () {
				window.location.href = "rate.php"});
				</script>' ;
		}
		else
		{
			echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Adding Courier. Please contact System Administrator",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "rate.php"});
				</script>' ;

		}

	}
	?>

<div id="myModal2" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Express</h4>
      </div>
      <div class="modal-body info">
          <form action="" method="post">
          <select class="form-control1" id="location" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							<select class="form-control1" name="dndox">
							<option value="">DOX / N-DOX</option>
                                    <option value="DOX">DOX</option>
                                    <option value="NDOX">N-DOX</option>
                                       
							</select>
        <p>Express</p>
      </div>
      <table align="center">
          <tr>
              <th style="width:25px">0.100</th>
              <th style="width:25px">0.250</th>
              <th style="width:25px">0.500</th>
              <th style="width:25px">Additional</th>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
      </table>
      <div class="modal-footer"></div>
      <div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<input type="submit" name="esave" value="save" class="btn btn-info">
			</div>
    </div>
    </form>
  </div>
</div>
<?php 
	

	if(isset($_POST['esave']))
	{

$location=$_POST['location'];
$dndox=$_POST['dndox'];
$field1=$_POST['100'];
$field2=$_POST['250'];
$field3=$_POST['500'];
$field4=$_POST['additional'];
date_default_timezone_set("Asia/Calcutta");
$date=date('Y-m-d h:i:s'); 

		


		$sql="INSERT INTO `trate` (`datetime`, `location`, `dndox`, `field1`, `field2`, `field3`, `field4`) VALUES 
		('$date', '$location', '$dndox', '$field1', '$field2', '$field3', '$field4')";

		$res=mysqli_query($conn,$sql);

		if($res)
		{
			echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Rate Added Successfully",
				icon: "success",
				button: "View rate",
				}).then(function () {
				window.location.href = "rate.php"});
				</script>' ;
		}
		else
		{
			echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Adding Courier. Please contact System Administrator",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "rate.php"});
				</script>' ;

		}

	}
	?>
<div id="myModal3" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Surface Cargo</h4>
      </div>
      <div class="modal-body info">
          <select class="form-control1" id="location" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							<select class="form-control1" name="dndox">
							<option value="">DOX / N-DOX</option>
                                    <option value="DOX">DOX</option>
                                    <option value="NDOX">N-DOX</option>
                                       
							</select>
       
      </div>
      <table align="center">
          <tr>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
      </table>
      <div class="modal-footer"></div>
      <div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<button type="button" name="save" id="save" class="btn btn-info">Save</button>
			</div>
    </div>
  </div>
</div>

<div id="myModal4" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Air Cargo</h4>
      </div>
      <div class="modal-body info">
          <select class="form-control1" id="location" name="location">
								    <option value="">-Location-</option>
   									<option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							<select class="form-control1" name="dndox">
							<option value="">DOX / N-DOX</option>
                                    <option value="DOX">DOX</option>
                                    <option value="NDOX">N-DOX</option>
                                       
							</select>
        <p>Air Cargo</p>
      </div>
      <table align="center">
          <tr>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
              <th style="width:25px;text-align:center">>=</th>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
      </table>
      <div class="modal-footer"></div>
      <div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<button type="button" name="save" id="save" class="btn btn-info">Save</button>
			</div>
    </div>
  </div>
</div>

<div id="myModal5" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">×</button>
        <h4 class="modal-title">Priority</h4>
      </div>
      <div class="modal-body info">
          <select class="form-control1" id="location" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
							<select class="form-control1" name="dndox">
							<option value="">DOX / N-DOX</option>
                                    <option value="DOX">DOX</option>
                                    <option value="NDOX">N-DOX</option>
                                       
							</select>
        <p>Priority</p>
      </div>
      <table align="center">
          <tr>
              <th style="width:25px">0.100</th>
              <th style="width:25px">0.250</th>
              <th style="width:25px">0.500</th>
              <th style="width:25px">Additional</th>
          </tr>
          <tr>
              <td><input type="text" name="100" value="" style="width:75px"></td>
              <td><input type="text" name="250" value="" style="width:75px"></td>
              <td><input type="text" name="500" value="" style="width:75px"></td>
              <td><input type="text" name="additional" value="" style="width:75px"></td>
          </tr>
      </table>
      <div class="modal-footer"></div>
      <div class="form-group" align="center">
				<input type="hidden" name="row_id" id="hidden_row_id" />
				<button type="button" name="save" id="save" class="btn btn-info">Save</button>
			</div>
    </div>
  </div>
</div>

<script>
    $("#selectbox").on("change", function() {
   var sOptionVal = $(this).val();
   if (/modal/i.test(sOptionVal)) {
     var $selectedOption = $(sOptionVal);
     $selectedOption.modal('show');
   }
 });
</script>


<script>  
$(document).ready(function(){ 
	
	var count = 0;

	$('#user_dialog').dialog({
		autoOpen:false,
		width:400
	});

	$('#add').click(function(){
		$('#user_dialog').dialog('option', 'title', 'Add Data');
		$('#first_name').val('');
		$('#last_name').val('');
		$('#dox').val('');
		
		$('#error_first_name').text('');
		$('#error_last_name').text('');
		$('#error_dox').text('');
		$('#first_name').css('border-color', '');
		$('#last_name').css('border-color', '');
		$('#dox').css('border-color', '');
		
		$('#save').text('Save');
		$('#user_dialog').dialog('open');
	});

	$('#save').click(function(){
		var error_first_name = '';
		var error_last_name = '';
		var error_dox = '';
		var first_name = '';
		var last_name = '';
		var dox = '';
		
		if($('#first_name').val() == '')
		{
			error_first_name = 'First Name is required';
			$('#error_first_name').text(error_first_name);
			$('#first_name').css('border-color', '#cc0000');
			first_name = '';
		}
		else
		{
			error_first_name = '';
			$('#error_first_name').text(error_first_name);
			$('#first_name').css('border-color', '');
			first_name = $('#first_name').val();
		}
	
		if($('#last_name').val() == '')
		{
			error_last_name = 'Last Name is required';
			$('#error_last_name').text(error_last_name);
			$('#last_name').css('border-color', '#cc0000');
			last_name = '';
		}
		else
		{
			error_last_name = '';
			$('#error_last_name').text(error_last_name);
			$('#last_name').css('border-color', '');
			last_name = $('#last_name').val();
		}
		if($('#dox').val() == '')
		{
			error_dox = 'dox / n-dox is required';
			$('#error_dox').text(error_dox);
			$('#dox').css('border-color', '#cc0000');
			dox = '';
		}
		else
		{
			error_dox = '';
			$('#error_dox').text(error_dox);
			$('#dox').css('border-color', '');
			dox = $('#dox').val();
		}
		if(error_first_name != '' || error_last_name != ''|| error_dox != '')
		{
			return false;
		}
		else
		{
			if($('#save').text() == 'Save')
			{
				count = count + 1;
				output = '<tr id="row_'+count+'">';
				output += '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+count+'" class="first_name" value="'+first_name+'" /></td>';
				output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+count+'" value="'+last_name+'" /></td>';
				output += '<td>'+dox+' <input type="hidden" name="hidden_dox[]" id="dox'+count+'" value="'+dox+'" /></td>';
				
				output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+count+'">View</button></td>';
				output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+count+'">Remove</button></td>';
				output += '</tr>';
				$('#user_data').append(output);
			}
			else
			{
				var row_id = $('#hidden_row_id').val();
				output = '<td>'+first_name+' <input type="hidden" name="hidden_first_name[]" id="first_name'+row_id+'" class="first_name" value="'+first_name+'" /></td>';
				output += '<td>'+last_name+' <input type="hidden" name="hidden_last_name[]" id="last_name'+row_id+'" value="'+last_name+'" /></td>';
				output += '<td>'+dox+' <input type="hidden" name="hidden_dox[]" id="dox'+row_id+'" value="'+dox+'" /></td>';
				
				output += '<td><button type="button" name="view_details" class="btn btn-warning btn-xs view_details" id="'+row_id+'">View</button></td>';
				output += '<td><button type="button" name="remove_details" class="btn btn-danger btn-xs remove_details" id="'+row_id+'">Remove</button></td>';
				$('#row_'+row_id+'').html(output);
			}

			$('#user_dialog').dialog('close');
		}
	});

	$(document).on('click', '.view_details', function(){
		var row_id = $(this).attr("id");
		var first_name = $('#first_name'+row_id+'').val();
		var last_name = $('#last_name'+row_id+'').val();
		var dox = $('#dox'+row_id+'').val();
		var customer_name = $('#customer_name'+row_id+'').val();
		var courier_name = $('#courier_name'+row_id+'').val();
		var mode = $('#mode'+row_id+'').val();
		var location = $('#location'+row_id+'').val();
		$('#first_name').val(first_name);
		$('#last_name').val(last_name);
		$('#dox').val(dox);
		$('#location').val(location);
		$('#save').text('Edit');
		$('#hidden_row_id').val(row_id);
		$('#user_dialog').dialog('option', 'title', 'Edit Data');
		$('#user_dialog').dialog('open');
	});

	$(document).on('click', '.remove_details', function(){
		var row_id = $(this).attr("id");
		if(confirm("Are you sure you want to remove this row data?"))
		{
			$('#row_'+row_id+'').remove();
		}
		else
		{
			return false;
		}
	});

	$('#action_alert').dialog({
		autoOpen:false
	});

	$('#user_form').on('submit', function(event){
		event.preventDefault();
		var count_data = 0;
		$('.first_name').each(function(){
			count_data = count_data + 1;
		});
		
			var form_data = $(this).serialize();
			$.ajax({
				url:"insert.php",
				method:"POST",
				data:form_data,
				success:function(data)
				{
					$('#user_data').find("tr:gt(0)").remove();
					$('#action_alert').html('<p>Data Inserted Successfully</p>');
					$('#action_alert').dialog('open');
				}
			})
		
		
	});
	
});  
</script>
						
		
    
 


					
					</form>
				</div>
			</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>
<?php
if(isset($_POST["submit"]))
{

                $url='103.50.160.62';
                $username='quickqpt_root';
                $password='helpdesk@123';
                $conn=mysqli_connect($url,$username,$password,"quickqpt_courier");
          if(!$conn){
          die('Could not Connect My Sql:' .mysqli_error());
		  }
		  $courier_name=$_POST['courier_name'];
		  $zone_type=$_POST['zone_type'];
          $file = $_FILES['file']['tmp_name'];
          $handle = fopen($file, "r");
          $c = 0;
          while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                    {
          $fname = $filesop[0];
          $lname = $filesop[1];
          $sql = "insert into zone_international(courier_name,zone_type,country_name,zone,mode) values ('$courier_name','$zone_type','$fname','$lname','international')";
          $stmt = mysqli_prepare($conn,$sql);
          mysqli_stmt_execute($stmt);

         $c = $c + 1;
           }

            if($sql){
               echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Zone Uploaded Successfully",
				icon: "success",
				button: "View zone",
				}).then(function () {
				window.location.href = "add_zone1.php"});
				</script>' ;
             } 
		 else
		 {
            echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Uploading zone. Please check uploading file",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "add_zone.php"});
				</script>' ;
          }

}
?>





<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {

        $('#example').DataTable();
    });
</script>
<div id="page-wrapper">
  <div class="graphs">
 
     

    <div class="xs tabls">
      <div class="bs-example4" data-example-id="contextual-table" style="overflow-y: scroll;">
        <table class="table table-hover" id="example" class="display" width="100%" cellspacing="0">
          <thead>
            <tr>
            
            <th>Id</th>
            
            <th>Courier Name</th>
              <th>Zone Type</th>
              <th>Country Name</th>
              <th>Zone Name</th>
              
              
             

            </tr>
          </thead>
          <tbody>
          <?php 
            $sql="Select * from zone_international order by id desc";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['id'];?></td>
             
			<td><?php echo $ros['courier_name'];?></td>
            <td><?php echo $ros['zone_type'];?></td>
            <td><?php echo $ros['country_name'];?></td>
            <td><?php echo $ros['zone'];?></td>
            
            
            
            
            

          </tr>
          <?php

        }
        ?>
       

          </tbody>


        </table>
      </div>
    </div>
  </div>
</div>
				
						
						
						
						<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"></label>
							<div class="col-sm-3">
								<button type="Submit" class="btn btn-success" name="Customer">Set Quantity</button>
								<button type="button" class="btn btn-success" name="Customer">Add Rate</button>
							</div>
						</div>-->

					
				</div>
			</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>

<?php
include('footer.php');
?>
	

