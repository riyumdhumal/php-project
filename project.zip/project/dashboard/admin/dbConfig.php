<?php
//db details
$dbHost = '103.50.160.62';
$dbUsername = 'quickqpt_root';
$dbPassword = 'helpdesk@123';
$dbName = 'quickqpt_courier';

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>