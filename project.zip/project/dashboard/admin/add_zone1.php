<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
                    $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#city').html(html);
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});
</script>
<div id="page-wrapper">
	<div class="graphs">
		<h3 class="blank1"> Add zone Details - International<button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_zone.php';">View zone</button></h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Courier Name:</label>
							<div class="col-sm-2">
								<select class="form-control" id="sel1" name="courier_name" >
							<option>select courier name</option>
								<?php
								$sql="Select * from courier where status='international'";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>
							</div>
							<label for="focusedinput" class="col-sm-1 control-label">Zone Type :</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="zone_type">+
							       
   									 <option value="EXPORT">EXPORT</option>
									 <option value="IMPORT">IMPORT</option>
									 
							</select>
							</div>
							
						
							<label for="focusedinput" class="col-sm-1 control-label">Country Name :</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="countrys_name">
							 <option value="">-- Select Country --</option>
   									 <option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Antigua and Barbuda">Antigua and Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas">Bahamas</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burundi">Burundi</option>
<option value="Cabo Verde">Cabo Verde</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo">Congo</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Cyprus">Cyprus</option>
<option value="Czech Republic (Czechia)">Czech Republic (Czechia)</option>
<option value="C么te d'Ivoire">C么te d'Ivoire</option>
<option value="Denmark">Denmark</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="DR Congo">DR Congo</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Eswatini">Eswatini</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="Gabon">Gabon</option>
<option value="Gambia">Gambia</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Greece">Greece</option>
<option value="Grenada">Grenada</option>
<option value="Guatemala">Guatemala</option>
<option value="Guinea">Guinea</option>
<option value="Guinea-Bissau">Guinea-Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Holy See">Holy See</option>
<option value="Honduras">Honduras</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia">Micronesia</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montenegro">Montenegro</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Myanmar">Myanmar</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="North Korea">North Korea</option>
<option value="North Macedonia">North Macedonia</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Qatar">Qatar</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Kitts & Nevis">Saint Kitts & Nevis</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome & Principe">Sao Tome & Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia">Serbia</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Korea">South Korea</option>
<option value="South Sudan">South Sudan</option>
<option value="Spain">Spain</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="St. Vincent & Grenadines">St. Vincent & Grenadines</option>
<option value="State of Palestine">State of Palestine</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Timor-Leste">Timor-Leste</option>
<option value="Togo">Togo</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad and Tobago">Trinidad and Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Tuvalu">Tuvalu</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="United States">United States</option>
<option value="Uruguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>

									 
							</select>
							</div>
						</div>
						
						
						
						<!--<div class="form-group">
   <label for="focusedinput" class="col-sm-2 control-label">Destination :</label> 
   <div class="col-sm-2">
 <div class="select-boxes">
    <?php
    //Include database configuration file
    include('dbConfig.php');
    
    //Get all country data
    $query = $db->query("SELECT * FROM countries WHERE status = 1 and country_name!='India' ORDER BY country_name ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    ?>
    <select name="destination" id="country" class="form-control">
        <option value="">-Select Destination-</option>
        <?php
        if($rowCount > 0){
            while($row = $query->fetch_assoc()){ 
                echo '<option value="'.$row['country_id'].'">'.$row['country_name'].'</option>';
            }
        }else{
            echo '<option value="">Country not available</option>';
        }
        ?>
    </select>
    </div>
    </div>
    <label for="focusedinput" class="col-sm-1 control-label">State :</label>
							<div class="col-sm-2">
    <select name="state" id="state" class="form-control">
        <option value="">-Select State-</option>
    </select>
                            </div>
                            <label for="focusedinput" class="col-sm-1 control-label">Location :</label>
							<div class="col-sm-2">
    <select class="form-control" id="location1" name="location1">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
    </div>
    </div>-->
						
						<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Character:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="char" placeholder="Enter Character" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Expo Character:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="expo_char" placeholder="Enter Expo Character" required="" id="dearname">
							</div>
						</div>
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Number:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="number" placeholder="Enter Number" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Expo Number:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="expo_number" placeholder="Enter Expo Number" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Phone:</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="phone" placeholder="Enter phone" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Mobile:</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="mobile" placeholder="Enter mobile" required="" id="dearname">
							</div>
						</div>

							<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Material Descrition:</label>
							<div class="col-sm-8">
							 <select class="form-control" id="sel1" name="material_descrition">
   									 <option value="document">document</option>
							</select>
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Email</label>
							<div class="col-sm-8">
								<input type="email" class="form-control1" name="email" placeholder="Enter email" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Password</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="password" placeholder="Enter password" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Web</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="web" placeholder="Enter web address" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">PAN</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="pan" placeholder="Enter PAN" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">GST</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="gst" placeholder="Enter GST" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Taxable Services</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="taxable" placeholder="Enter Taxable Services" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Judidial</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="judidial" placeholder="Enter Judidial" required="" >
							</div>
						</div>-->
						
						
						

							<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Category</label>
							<div class="col-sm-8">
							<select class="form-control" id="sel1" name="Category">
   									 <option value="speed">speed</option>
   									 <option value="spical">spical</option>
   									 <option value="normal">normal</option>
							</select>
							</div>
						</div>
					
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Corporate id</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Corporateid" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Shipping charge</label>
							<div class="col-sm-8">
								<input type="number" class="form-control1" name="shappingcharge" placeholder="Enter Shipping charge" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch Id :</label>
							<div class="col-sm-8">
								<select class="form-control" id="sel1" name="branchid" >
							<option>select</option>
								<?php
								$sql="Select * from branch";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['branch_id'];?>"><?php echo $ros['branch_id'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Date of booking :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="dateofbooking" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"> book at Branch :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="booked_at_branch" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch location :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="branchlocation" placeholder="Enter branch location" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">destination :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="destination" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver name :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="reciver_name" placeholder="Enter Reciver name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="rciveraddress" placeholder="Enter Reciver Address" required="">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Phone no :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Reciver_phone_no" placeholder="Enter Reciver Phone no" required="" >
							</div>
						</div>-->

    <div class="form-group">
        <label for="focusedinput" class="col-sm-2 control-label">Zone Name</label>
        <div class="col-sm-2">
        <input type="text" name="individual" value="" placeholder="enter zone name" class="form-control1">
        
        </div>
        <label for="focusedinput" class="col-sm-4 control-label">File Upload</label>
        <div class="col-sm-4">
        <input type="file" name="file" id="file" size="150">
        <p class="help-block">Only CSV File Import.</p>
        </div>
    </div>
 


						<div class="form-group">
						    <label for="focusedinput" class="col-sm-2 control-label"></label>
							<div class="col-sm-4">
							    <button type="Submit" class="btn btn-success" name="insert">Insert Individual</button>
								
							</div>
							<label for="focusedinput" class="col-sm-2 control-label"></label>
							<div class="col-sm-4">
							    
								<button type="Submit" class="btn btn-success" name="submit">File Upload</button>
								<a href=""><button type="button" class="btn btn-danger">Cancel</button></a>
							</div>
						</div>

					</form>
				</div>
			</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>
<?php
if(isset($_POST["submit"]))
{

                $url='103.50.160.62';
                $username='quickqpt_root';
                $password='helpdesk@123';
                $conn=mysqli_connect($url,$username,$password,"quickqpt_courier");
          if(!$conn){
          die('Could not Connect My Sql:' .mysqli_error());
		  }
		  $courier_name=$_POST['courier_name'];
		  $zone_type=$_POST['zone_type'];
          $file = $_FILES['file']['tmp_name'];
          $handle = fopen($file, "r");
          $c = 0;
          while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                    {
          $fname = $filesop[0];
          $lname = $filesop[1];
          $sql = "insert into zone_international(courier_name,zone_type,country_name,zone,mode) values ('$courier_name','$zone_type','$fname','$lname','international')";
          $stmt = mysqli_prepare($conn,$sql);
          mysqli_stmt_execute($stmt);

         $c = $c + 1;
           }

            if($sql){
               echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Zone Uploaded Successfully",
				icon: "success",
				button: "View zone",
				}).then(function () {
				window.location.href = "add_zone1.php"});
				</script>' ;
             } 
		 else
		 {
            echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Uploading zone. Please check uploading file",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "add_zone.php"});
				</script>' ;
          }

}
?>


<?php
if(isset($_POST["insert"]))
{

                $url='103.50.160.62';
                $username='quickqpt_root';
                $password='helpdesk@123';
                $conn=mysqli_connect($url,$username,$password,"quickqpt_courier");
          if(!$conn){
          die('Could not Connect My Sql:' .mysqli_error());
		  }
		  $courier_name=$_POST['courier_name'];
		  $zone_type=$_POST['zone_type'];
		  $countrys_name=$_POST['countrys_name'];
		  $individual=$_POST['individual'];
          
         
          $sql = "insert into zone_international(courier_name,zone_type,country_name,zone,mode) values ('$courier_name','$zone_type','$countrys_name','$individual','international')";
          $stmt = mysqli_prepare($conn,$sql);
          mysqli_stmt_execute($stmt);

         

            if($sql){
               echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "Zone inserted Successfully",
				icon: "success",
				button: "View zone",
				}).then(function () {
				window.location.href = "add_zone1.php"});
				</script>' ;
             } 
		 else
		 {
            echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in inserting zone. Please check your Data",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "add_zone.php"});
				</script>' ;
          }

}
?>


<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function () {

        $('#example').DataTable();
    });
</script>
<div id="page-wrapper">
  <div class="graphs">
 
     

    <div class="xs tabls">
      <div class="bs-example4" data-example-id="contextual-table" style="overflow-y: scroll;">
        <table class="table table-hover" id="example" class="display" width="100%" cellspacing="0">
          <thead>
            <tr>
            
            <th>Id</th>
            
            <th>Courier Name</th>
              <th>Zone Type</th>
              <th>Country Name</th>
              <th>Zone Name</th>
              
              
             

            </tr>
          </thead>
          <tbody>
          <?php 
            $sql="Select * from zone_international order by id desc";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['id'];?></td>
             
			<td><?php echo $ros['courier_name'];?></td>
            <td><?php echo $ros['zone_type'];?></td>
            <td><?php echo $ros['country_name'];?></td>
            <td><?php echo $ros['zone'];?></td>
            
            
            
            
            

          </tr>
          <?php

        }
        ?>
       

          </tbody>


        </table>
      </div>
    </div>
  </div>
</div>


	<?php 
	include('footer.php');

	
	?>


