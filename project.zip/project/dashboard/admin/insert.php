<?php

//insert.php

$connect = new PDO("mysql:host=103.50.160.62;dbname=quickqpt_courier", "quickqpt_root", "helpdesk@123");


$query = "
INSERT INTO tbl_sample 
(first_name, last_name, customer_name, courier_name, mode, dox, location) 
VALUES (:first_name, :last_name, :customer_name, :courier_name, :mode, :dox, :location)
";

for($count = 0; $count<count($_POST['hidden_first_name']); $count++)
{
	$data = array(
		':first_name'	=>	$_POST['hidden_first_name'][$count],
		':last_name'	=>	$_POST['hidden_last_name'][$count],
		':dox'	=>	$_POST['hidden_dox'][$count],
		':customer_name'	=>	$_POST['customer_name'],
		':courier_name'	=>	$_POST['courier_name'],
		':mode'	=>	$_POST['mode'],
		':location'	=>	$_POST['location']
	);
	$statement = $connect->prepare($query);
	$statement->execute($data);
}

?>