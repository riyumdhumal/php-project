<?php  
 //load_data.php  
 $connect = mysqli_connect("103.50.160.62", "quickqpt_root", "helpdesk@123", "quickqpt_courier");  
 $output = '';  
 if(isset($_POST["brand_id"]))  
 {  
      if($_POST["brand_id"] != '')  
      {  
           $sql = "SELECT * FROM tbl_sample WHERE courier_name = '".$_POST["brand_id"]."'";  
      }  
      else  
      {  
           $sql = "SELECT * FROM tbl_sample";  
      }  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '<select><option>'.$row["first_name"].'</option></select>';  
      }  
      echo $output;  
 }  
 ?>  