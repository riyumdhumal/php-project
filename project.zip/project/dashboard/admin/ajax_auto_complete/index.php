<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Detail Article</title>
<link type="text/css" rel="stylesheet" href="css/style.css" />

<link href="css/bootstrap.css" rel="stylesheet" />
 <link href="css/animate.css" rel="stylesheet">
 <link rel="icon" type="image/png" href="images/slpfavicon.png" />
 <link rel="stylesheet" type="text/css" href="css/jquery.ajaxcomplete.css" />
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.ajaxcomplete.js"></script>
<script>
$(document).ready(function(){
 $("#country").autocomplete("ajaxcomplete.php", {
		selectFirst: true
	});
});
</script>
</head>

<body>
<div class="maincontainer">
		 <header class="header">
             	   <div class="hadeLogo" >
                    <a class="navbar-brand" href="Article.aspx" style="color: #fff">
                        <img src="images/logo (1).png" alt="Simply Learn Programming" style="margin-top:-12%;" /></a>
             	   </div>
      <nav class="navbar navbar-default">
           <div class="container-fluid">
           <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <!-- Brand and toggle get grouped for better mobile display -->
           <div class="navbar-header">
      

          </div>

                        
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

 
                        </div>
                        <!-- /.navbar-collapse -->
                    </div>
                    <!-- /.container-fluid -->
                </nav>
            </header>
     <div class="mainclass">
     <div class="titel">
     <h3>Auto Complete</h3>
</div>
<hr  class="hr"/>

            
    <div class="middel_div_right">
       
<label>eg.Samsung Galaxy, Lenovo Vibe, Lava, Xiaomi Redmi</label><br />


  <label>Enter Mobile Name : </label>
    <input name="country" type="text" id="country" style="height:35px; width:200px;"/>
          
   </div>
  
</body>
</html>