<?php
	$name=$_GET['name'];
	$conn=mysql_connect('localhost','root','') or die("Database Error");
	mysql_select_db('speed_age',$conn);
	$sql="SELECT * FROM customer WHERE name LIKE '%$name%' ORDER BY id LIMIT 10";
	$result = mysql_query($sql) or die(mysql_error());
	
	if($result)
	{
		while($row=mysql_fetch_array($result))
		{
			echo $row['name']."\n";
		}
	}
?>