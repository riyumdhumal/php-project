<?php 

include('header.php');
include('sidebar.php');
include('../connection.php');

?>
<link rel="stylesheet" href="http://cdn.datatables.net/1.10.2/css/jquery.dataTables.min.css"></style>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.2/js/jquery.dataTables.min.js"></script>

<script>
    $(document).ready(function () {

        $('#example').DataTable();
    });
</script>
<div id="page-wrapper">
  <div class="graphs">
    <h3 class="blank1">View entry <button style="float:right" class="btn btn-success" onclick="window.location.href = 'add_entry.php';">Add Entry</button></h3>

    <div class="xs tabls">
      <div class="bs-example4" data-example-id="contextual-table" style="overflow-y: scroll;">
        <table class="table table-hover" id="example" class="display" width="100%" cellspacing="0">
          <thead>
            <tr>
			<th>	Entry Date	</th>
			<th>	Bill Type	</th>
			<th>	Service Type	</th>
			<th>	Courier Type	</th>
			<th>	Customer Name	</th>
			<th>	Branch	</th>
			<th>	AWB No	</th>
			<th>	Forwading No	</th>
			<th>	Destination	</th>
			<th>	State	</th>
			<th>	Location	</th>
			<th>	Receiver Name	</th>
			<th>	Receiver Address	</th>
			<th>	Courier Name	</th>
			<th>	Mode	</th>
			<th>	Type	</th>
			<th>	Weight	</th>
			<th>	Amount	</th>
			<th>	Other Charges	</th>
			<th>	Total Amount	</th>
			<th>	Action	</th>

             

            </tr>
          </thead>
          <tbody>
          <?php 
            $sql="Select `id`,`entry_date`, `bill_type`, `service_type`, `courier_type`, `customer_name`, `branch`, `awb_no`, `forwading_no`, `destination`, 
            `state`, `location`, `receiver_name`, `receiver_address`, `courier_name`, `mode`, `type`, `weight`, `amount`, `other_charges`, `total_amount` from entry";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['entry_date'];?></td>
			<td><?php echo $ros['bill_type'];?></td>
			<td><?php echo $ros['service_type'];?></td>
			<td><?php echo $ros['courier_type'];?></td>
			<td><?php echo $ros['customer_name'];?></td>
			<td><?php echo $ros['branch'];?></td>
			<td><?php echo $ros['awb_no'];?></td>
			<td><?php echo $ros['forwading_no'];?></td>
			<td><?php echo $ros['destination'];?></td>
			<td><?php echo $ros['state'];?></td>
			<td><?php echo $ros['location'];?></td>
			<td><?php echo $ros['receiver_name'];?></td>
			<td><?php echo $ros['receiver_address'];?></td>
			<td><?php echo $ros['courier_name'];?></td>
			<td><?php echo $ros['mode'];?></td>
			<td><?php echo $ros['type'];?></td>
			<td><?php echo $ros['weight'];?></td>
			<td><?php echo $ros['amount'];?></td>
			<td><?php echo $ros['other_charges'];?></td>
            <td><?php echo $ros['total_amount'];?></td>
            <td><a href="edit_entry.php?id=<?php echo $ros['id'];?>">EDIT</a></td>
			
            
            

          </tr>
          <?php

        }
        ?>
       

          </tbody>


        </table>
      </div>
    </div>
  </div>
</div>

<?php

include('footer.php');


if(isset($_REQUEST['deleteid']))
{

$id=$_REQUEST['deleteid'];

$sql="DELETE FROM `customer` WHERE `customer`.`id` = '$id'";


    $res=mysqli_query($conn,$sql);

    if($res)
    {
      echo"<script>alert('Delete sucessfully');window.location='view_customer.php'</script>";
    }
    else
    {
      echo"<script>alert('data Delete error');window.location='view_customer.php'</script>";

    }


}
?>
