<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<link rel="stylesheet" href="auto.css" type="text/css" /> 
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>	
<script type="text/javascript">
$(function() {
	
	//autocomplete
	$(".auto").autocomplete({
		source: "search.php",
		minLength: 1
	});				

});
</script>
 <script>
function getCountry(val) {
$.ajax({
    type: "POST",
    url: "get_country.php",
    data:'region_id='+val,

   success: function(data){
    $("#country-list").html(data);
  }
  });
  }

  function selectRegion(val) {
  $("#search-box").val(val); 
  $("#suggesstion-box").hide();
  }
  </script>
 

<style>  
           ul{  
                background-color:#eee;  
                cursor:pointer;  
           }  
             
           </style>  
<script type="text/javascript">
$(document).ready(function(){
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
                    $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'ajaxData.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#city').html(html);
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});
</script>
<?php
 $username = "quickqpt_root";
 $password = "helpdesk@123";
 $host = "103.50.160.62";
 $connector = mysql_connect($host, $username, $password)
    or die("Unable to connect");
 $selected = mysql_select_db("quickqpt_courier", $connector)
    or die("Unable to connect");
 ?>
<?php

	$phone= $_GET['id'];
    
    $result = mysql_query("SELECT * FROM entry WHERE id='$phone' ORDER BY id DESC LIMIT 1");


?>
<?php while($rows=mysql_fetch_array($result)):?>
<div id="page-wrapper">
	<div class="graphs">
	<label for="focusedinput" class="col-sm-1 control-label">Entry Date:</label>
							<div class="col-sm-2">
					<input type="date" class="form-control1" name="entry_date" value="<?php echo $rows ['date'];?>" id="dearname">
							</div>
							
		<h3 class="blank1" style="float:center"> Air way bill entry  <button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_entry.php';">View Entry</button></h3>
		<div class="col-sm-12">
		
			<div class="col-sm-2">
			
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				
				
				
						<div class="form-group">
							
							<label for="focusedinput" class="col-sm-1 control-label">Bill Type:</label>
							<div class="col-sm-2">
					<select class="form-control" id="sel1" name="bill_type">
					    <option value="<?php echo $rows ['bill_type'];?>"><?php echo $rows ['bill_type'];?></option>
   									 <option value="credit">Credit</option>
									 <option value="cash">Cash</option>
							</select>
					
							</div>
							
							<label for="focusedinput" class="col-sm-1 control-label">Service Type:</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="service_type">
							     <option value="<?php echo $rows ['service_type'];?>"><?php echo $rows ['service_type'];?></option>
   									 <option value="domestic">Domestic</option>
									 <option value="international">International</option>
							</select>
							</div>
							<label for="focusedinput" class="col-sm-1 control-label">Courier Type:</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="courier_type">
							     		 <option value="<?php echo $rows ['courier_type'];?>"><?php echo $rows ['courier_type'];?></option>
   									 <option value="export">Export</option>
									 <option value="import">Import</option>
							</select>
							</div>
						</div>
						
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-1 control-label">Customer Name :</label>
							<div class="col-sm-5">
								<input type='text' name='customer_name' value="<?php echo $rows ['customer_name'];?>" class="auto form-control"  onChange="getCountry(this.value);">  
								
							</div>
							
							<label for="focusedinput" class="col-sm-1 control-label">Branch :</label>
							<div class="col-sm-2">
							<select name="branch" id="country-list" class="form-control">
                            <option value="<?php echo $rows ['branch'];?>"><?php echo $rows ['branch'];?></option>
							</select> 
							
							</div>
							
							</div>
						
						
						
							
							<div class="form-group">
							<label for="focusedinput" class="col-sm-1 control-label">AWB No :</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="awb_no" value="<?php echo $rows ['awb_no'];?>" required="" id="dearname">
							</div>
							<label for="focusedinput" class="col-sm-2 control-label">Forwading No :</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="forwading_no" value="<?php echo $rows ['forwading_no'];?>" required="" id="dearname">
							</div>
						</div>
						
						
						

<div class="form-group">
   <label for="focusedinput" class="col-sm-1 control-label">Destination :</label> 
   <div class="col-sm-2">
 <div class="select-boxes">
    <?php
    //Include database configuration file
    include('dbConfig.php');
    
    //Get all country data
    $query = $db->query("SELECT * FROM countries WHERE status = 1 ORDER BY country_name ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    ?>
    <select name="destination" id="country" class="form-control">
        <option value="<?php echo $rows ['destination'];?>"><?php echo $rows ['destination'];?></option>
        <?php
        if($rowCount > 0){
            while($row = $query->fetch_assoc()){ 
                echo '<option value="'.$row['country_id'].'">'.$row['country_name'].'</option>';
            }
        }else{
            echo '<option value="">Country not available</option>';
        }
        ?>
    </select>
    </div>
    </div>
    <label for="focusedinput" class="col-sm-1 control-label">State :</label>
							<div class="col-sm-2">
    <select name="state" id="state" class="form-control">
        <option value="<?php echo $rows ['state'];?>"><?php echo $rows ['state'];?></option>
    </select>
                            </div>
                            <label for="focusedinput" class="col-sm-1 control-label">Location :</label>
							<div class="col-sm-2">
    <select name="location" id="city" class="form-control">
        <option value="<?php echo $rows ['location'];?>"><?php echo $rows ['location'];?></option>
    </select>
    </div>
    </div>


	




	
	                    
						
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-1 control-label">Receiver Name :</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="receiver_name" value="<?php echo $rows ['receiver_name'];?>" required="" id="dearname">
							</div>
							<label for="focusedinput" class="col-sm-1 control-label">Receiver Address :</label>
							<div class="col-sm-4">
								<input type="text" class="form-control1" name="receiver_address" value="<?php echo $rows ['receiver_address'];?>" required="" id="dearname">
							</div>
							
						</div>
						
						
						
							<div class="form-group">
							
						
							<label for="focusedinput" class="col-sm-1 control-label">Courier Name :</label>
							<div class="col-sm-2">
								<select class="form-control" id="sel1" name="courier_name" >
							<option value="<?php echo $rows ['courier_name'];?>"><?php echo $rows ['courier_name'];?></option>
								<?php
								$sql="Select * from courier";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						    <label for="focusedinput" class="col-sm-1 control-label">Mode :</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="mode">
							     <option value="<?php echo $rows ['mode'];?>"><?php echo $rows ['mode'];?></option>
   									 <option value="Standard">Standard</option>
									 <option value="Express">Express</option>
									 <option value="Surface">Surface Cargo</option>
									 <option value="Air">Air Cargo</option>
									 <option value="Priority">Priority</option>
									 
							</select>
							</div>
							<label for="focusedinput" class="col-sm-1 control-label">Type:</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="type">
							     <option value="<?php echo $rows ['type'];?>"><?php echo $rows ['type'];?></option>
   									 <option value="DOX">DOX</option>
									 <option value="N-DOX">N-DOX</option>
									 
							</select>
							</div>
							</div>
							
							
							
							
						<div class="form-group">
							
						
							
						
							<label for="focusedinput" class="col-sm-1 control-label">Weight :</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="weight" value="<?php echo $rows ['weight'];?>" required="" id="dearname">
							</div>
						
							
						
							<label for="focusedinput" class="col-sm-1 control-label">Amount :</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="amount" value="<?php echo $rows ['amount'];?>" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-1 control-label">Other Charges :</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="other_charges">
   									 <option value="Standard">Commercial</option>
									 <option value="Express">Remote</option>
									 <option value="Surface">Risk Sur</option>
									 <option value="Air">Air Cargo</option>
									 <option value="Priority">NA</option>
									 
							</select>
							</div>
						</div>
						
						
						
						
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-1 control-label">Total Amount :</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="total_amount" value="<?php echo $rows ['total_amount'];?>" required="" id="dearname">
							</div>
							
							<?php endwhile;?>
						<label for="focusedinput" class="col-sm-1 control-label"></label>
							<div class="col-sm-4">
								<button type="Submit" class="btn btn-success" name="Consignment">Submit</button>
								<a href=""><button type="button" class="btn btn-danger">Cancel</button></a>
							</div>
							<!--<label for="focusedinput" class="col-sm-1 control-label">Delivery Status:</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="delivery_status">
   									 <option value="in_transit">In Transit</option>
									 <option value="import">ABC</option>
									 <option value="import">XYZ</option>
							</select>
							</div>
						
							<label for="focusedinput" class="col-sm-1 control-label">Delivery Date :</label>
							<div class="col-sm-2">
								<input type="date" class="form-control1" name="delivery_date" placeholder="Enter Delivery Date" required="" id="dearname">
							</div>-->
						</div>
						
						
						
						
						
						<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-1 control-label">Delivery Time :</label>
							<div class="col-sm-2">
								<input type="time" class="form-control1" name="delivery_time" placeholder="Enter Delivery Time" required="" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-1 control-label">Received by :</label>
							<div class="col-sm-2">
								<input type="text" class="form-control1" name="received_by" placeholder="Enter Received by" required="" id="dearname">
							</div>
						</div>-->
						
						
						
						
						
						
						
						

							<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Shipper address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="shipperaddress" placeholder="Enter shapping addrerss" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Phone:</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Phone" placeholder="Enter phone" required="" id="dearname">
							</div>
						</div>

							<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Material Descrition:</label>
							<div class="col-sm-8">
							 <select class="form-control" id="sel1" name="material_descrition">
   									 <option value="document">document</option>
							</select>
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">No of item</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="noofitem" placeholder="Enter no of item" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Total weight</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="totalwight" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>

							<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Category</label>
							<div class="col-sm-8">
							<select class="form-control" id="sel1" name="Category">
   									 <option value="speed">speed</option>
   									 <option value="spical">spical</option>
   									 <option value="normal">normal</option>
							</select>
							</div>
						</div>
					
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Corporate id</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Corporateid" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Shipping charge</label>
							<div class="col-sm-8">
								<input type="number" class="form-control1" name="shappingcharge" placeholder="Enter Shipping charge" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch Id :</label>
							<div class="col-sm-8">
								<select class="form-control" id="sel1" name="branchid" >
							<option>select</option>
								<?php
								$sql="Select * from branch";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['branch_id'];?>"><?php echo $ros['branch_id'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Date of booking :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="dateofbooking" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"> book at Branch :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="booked_at_branch" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch location :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="branchlocation" placeholder="Enter branch location" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">destination :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="destination" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver name :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="reciver_name" placeholder="Enter Reciver name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="rciveraddress" placeholder="Enter Reciver Address" required="">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Phone no :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Reciver_phone_no" placeholder="Enter Reciver Phone no" required="" >
							</div>
						</div>-->



						

					</form>
				</div>
			</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>


	<?php 
	include('footer.php');

	if(isset($_REQUEST['Consignment']))
	{

$entry_date=$_REQUEST['entry_date'];
$bill_type=$_REQUEST['bill_type'];
$service_type=$_REQUEST['service_type'];
$courier_type=$_REQUEST['courier_type'];
$customer_name=$_REQUEST['customer_name'];
$branch=$_REQUEST['branch'];
$awb_no=$_REQUEST['awb_no'];
$forwading_no=$_REQUEST['forwading_no'];
$destination=$_REQUEST['destination'];
$state=$_REQUEST['state'];
$location=$_REQUEST['location'];
$receiver_name=$_REQUEST['receiver_name'];
$receiver_address=$_REQUEST['receiver_address'];
$courier_name=$_REQUEST['courier_name'];
$mode=$_REQUEST['mode'];
$type=$_REQUEST['type'];
$weight=$_REQUEST['weight'];
$amount=$_REQUEST['amount'];
$other_charges=$_REQUEST['other_charges'];
$total_amount=$_REQUEST['total_amount'];


date_default_timezone_set("Asia/Calcutta");
$date=date('Y-m-d h:i:s'); 
$ccn="Book".time();
$bookingid="BOOK".time();
	


		$sql="update entry set datetime='$date',entry_date='$entry_date',bill_type='$bill_type',service_type='$service_type',courier_type='$courier_type',
		customer_name='$customer_name',branch='$branch',awb_no='$awb_no',forwading_no='$forwading_no',destination='$destination',state='$state',location='$location',
		receiver_name='$receiver_name',receiver_address='$receiver_address',courier_name='$courier_name',mode='$mode',type='$type',weight='$weight',
		amount='$amount',other_charges='$other_charges',total_amount='$total_amount' where id='$phone'";

		$res=mysqli_query($conn,$sql);

		if($res)
		{
			echo '<script>
				swal("Successfully Updated", {
				title: "Updated!",
				text: "Entry Updated Successfully",
				icon: "success",
				button: "View Entries",
				}).then(function () {
				window.location.href = "view_entry.php"});
				</script>' ;
		}
		else
		{
			echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Updating entry. Please contact System Administrator",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "add_entry.php"});
				</script>' ;

		}

	}
	?>

