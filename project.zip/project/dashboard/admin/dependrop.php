<?php
require_once 'ajaxpro.php';
$query   = "SELECT * FROM geo";
$results = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
<title>DDL - Select</title>
</head><?php
$bul[10000007] = false;
?>

<style>
body{width:610px;}
.frmDronpDown {border: 1px solid #F0F0F0;background-color:#C8EEFD;margin: 2px       0px;padding:40px;}
.demoInputBox {padding: 10px;border: #F0F0F0 1px solid;border-radius:  4px;background-color: #FFF;width: 50%;}
.row{padding-bottom:15px;}
</style>
<script src="https://code.jquery.com/jquery-2.1.1.min.js"   type="text/javascript"></script>
<script>
function getCountry(val) {
$.ajax({
    type: "POST",
    url: "get_country.php",
    data:'region_id='+val,

   success: function(data){
    $("#country-list").html(data);
  }
  });
  }

  function selectRegion(val) {
  $("#search-box").val(val); 
  $("#suggesstion-box").hide();
  }
  </script>

 <body>
<div class="frmDronpDown">
<div class="row">

<form>
<label>Region: </label>
<select name="region" id="region-list" class="demoInputBox"      onChange="getCountry(this.value);">
    <option value="">Select Region</option>

        <?php
$sql = "SELECT * FROM customer";
$res = mysqli_query($conn, $sql);
while ($row = mysqli_fetch_assoc($res)) {
    if ($bul[$row['name']] != true && $row['name'] != 'name') {
?>
               <option value="<?php
        echo $row['name'];
?>"><?php
        echo $row['name'];
?></option>
        <?php
        $bul[$row['name']] = true;
    }
}
?>

    </select>
</div>

<div class="row">
    <label>Country: </label>
    <select name="country" id="country-list" class="demoInputBox">
        
    </select>   

</form>
</div>
</div>
</body>
</html>