<!--footer section start-->
<footer>
  <p>&copy 2018 Admin Panel. All Rights Reserved | Design by <a href="#">Admin panel</a></p>
</footer>
<!--footer section end-->

<!-- main content end-->
</section>

<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>
</body>
</html>