<?php
include('header.php');
include('sidebar.php');

include('../connection.php');	


?>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
<link rel="stylesheet" href="auto.css" type="text/css" /> 
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="http://code.jquery.com/ui/1.10.1/jquery-ui.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
    $('#country').on('change',function(){
        var countryID = $(this).val();
        if(countryID){
            $.ajax({
                type:'POST',
                url:'ajaxData1.php',
                data:'country_id='+countryID,
                success:function(html){
                    $('#state').html(html);
                    $('#city').html('<option value="">Select state first</option>'); 
                }
            }); 
        }else{
            $('#state').html('<option value="">Select country first</option>');
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
    
    $('#state').on('change',function(){
        var stateID = $(this).val();
        if(stateID){
            $.ajax({
                type:'POST',
                url:'ajaxData1.php',
                data:'state_id='+stateID,
                success:function(html){
                    $('#city').html(html);
                }
            }); 
        }else{
            $('#city').html('<option value="">Select state first</option>'); 
        }
    });
});
</script>
<script type="text/javascript">
$(function() {
	
	//autocomplete
	$(".auto").autocomplete({
		source: "search.php",
		minLength: 1
	});				

});
</script>
<style>  
           ul{  
                background-color:#eee;  
                cursor:pointer;  
           }  
             
           </style> 
<div id="page-wrapper">
	<div class="graphs">
		<h3 class="blank1"> Add zone Details - Domestic<button style="float:right" class="btn btn-success" onclick="window.location.href = 'view_zone.php';">View zone</button></h3>
		<div class="col-sm-12">
			<div class="col-sm-2">
			</div>
			<div class="col-sm-2">
			</div>
		</div>
		<div class="tab-content">
			<div class="tab-pane active" id="horizontal-form">
				<form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
				
						<div class="form-group">
						    <label for="focusedinput" class="col-sm-2 control-label">Customer Name :</label>
						
							 <div class="col-sm-2">
								<input type="text" name="customer_name" class="auto form-control">  
                            </div>
							
							
							
							<label for="focusedinput" class="col-sm-1 control-label">Courier Name:</label>
							<div class="col-sm-2">
								<select class="form-control" id="sel1" name="courier_name" >
							<option>select courier name</option>
								<?php
								$sql="Select * from courier where status='domestic'";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['name'];?>"><?php echo $ros['name'];?></option>
									<?php
								}
									?>
								</select>
							</div>
							<label for="focusedinput" class="col-sm-1 control-label">Zone Type :</label>
							<div class="col-sm-2">
							 <select class="form-control" id="sel1" name="zone_type">
   									 <option value="Standard">Standard</option>
									 <option value="Express">Express</option>
									 <option value="Surface">Surface Cargo</option>
									 <option value="Air">Air Cargo</option>
									 <option value="Priority">Priority</option>
									 
							</select>
							</div>
							
						</div>

							
						
						
						
						<div class="form-group">
    <label for="focusedinput" class="col-sm-2 control-label">City :</label> 
   <div class="col-sm-2">
 <div class="select-boxes">
    <?php
    //Include database configuration file
    include('dbConfig.php');
    
    //Get all country data
    $query = $db->query("SELECT * FROM countries1 WHERE status = 1 GROUP BY country_name ORDER BY country_name ASC");
    
    //Count total number of rows
    $rowCount = $query->num_rows;
    ?>
    <select name="city" id="country" class="form-control">
        <option value="">-Select Destination-</option>
        <?php
        if($rowCount > 0){
            while($row = $query->fetch_assoc()){ 
                echo '<option value="'.$row['country_id'].'">'.$row['country_name'].'</option>';
            }
        }else{
            echo '<option value="">Country not available</option>';
        }
        ?>
    </select>
    </div>
    </div>
    <label for="focusedinput" class="col-sm-1 control-label">State :</label>
							<div class="col-sm-2">
    <select name="state" id="state" class="form-control">
        
    </select>
                            </div>
                            <label for="focusedinput" class="col-sm-1 control-label">Location :</label>
							<div class="col-sm-2">
    <select class="form-control" id="location1" name="location">
								    <option value="">-Location-</option>
   									 <option value="ALL OVER INDIA">ALL OVER INDIA</option>
                                    <option value="CENTRAL">CENTRAL</option>
                                    <option value="DELHI">DELHI</option>
                                    <option value="EAST">EAST</option>
                                    <option value="GOA">GOA</option>
                                    <option value="GUJRAT">GUJRAT</option>
                                    <option value="JAMMU & KASHMIR">JAMMU & KASHMIR</option>
                                    <option value="KERALA">KERALA</option>
                                    <option value="LOCAL">LOCAL</option>
                                    <option value="MAHARASHTRA">MAHARASHTRA</option>
                                    <option value="METRO">METRO</option>
                                    <option value="NORTH">NORTH</option>
                                    <option value="NORTH EAST">NORTH EAST</option>
                                    <option value="OUT OF B.M.C. LIMIT">OUT OF B.M.C. LIMIT</option>
                                    <option value="PUNE">PUNE</option>
                                    <option value="RAIGAD">RAIGAD</option>
                                    <option value="REST OF INDIA">REST OF INDIA</option>
                                    <option value="SOUTH">SOUTH</option>
                                    <option value="WEST">WEST</option>
                                    <option value="ZONE 1">ZONE 1</option>
                                    <option value="ZONE 2">ZONE 2</option>
                                    <option value="ZONE 3">ZONE 3</option>
                                    <option value="ZONE 4">ZONE 4</option>
									 
							</select>
    </div>
    </div>
						
						<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Character:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="char" placeholder="Enter Character"  id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Expo Character:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="expo_char" placeholder="Enter Expo Character"  id="dearname">
							</div>
						</div>
						
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Number:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="number" placeholder="Enter Number" id="dearname">
							</div>
						
							<label for="focusedinput" class="col-sm-2 control-label">Expo Number:</label>
							<div class="col-sm-3">
								<input type="text" class="form-control1" name="expo_number" placeholder="Enter Expo Number" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Phone:</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="phone" placeholder="Enter phone" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Mobile:</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="mobile" placeholder="Enter mobile" required="" id="dearname">
							</div>
						</div>

							<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Material Descrition:</label>
							<div class="col-sm-8">
							 <select class="form-control" id="sel1" name="material_descrition">
   									 <option value="document">document</option>
							</select>
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Email</label>
							<div class="col-sm-8">
								<input type="email" class="form-control1" name="email" placeholder="Enter email" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Password</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="password" placeholder="Enter password" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Web</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="web" placeholder="Enter web address" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">PAN</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="pan" placeholder="Enter PAN" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">GST</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="gst" placeholder="Enter GST" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Taxable Services</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="taxable" placeholder="Enter Taxable Services" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Judidial</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="judidial" placeholder="Enter Judidial" required="" >
							</div>
						</div>-->
						
						
						

							<!--<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Category</label>
							<div class="col-sm-8">
							<select class="form-control" id="sel1" name="Category">
   									 <option value="speed">speed</option>
   									 <option value="spical">spical</option>
   									 <option value="normal">normal</option>
							</select>
							</div>
						</div>
					
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Corporate id</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Corporateid" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Shipping charge</label>
							<div class="col-sm-8">
								<input type="number" class="form-control1" name="shappingcharge" placeholder="Enter Shipping charge" required="" >
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch Id :</label>
							<div class="col-sm-8">
								<select class="form-control" id="sel1" name="branchid" >
							<option>select</option>
								<?php
								$sql="Select * from branch";
								$res=mysqli_query($conn,$sql);
								
								while($ros=mysqli_fetch_array($res))
								{
									?>
									<option value="<?php echo $ros['branch_id'];?>"><?php echo $ros['branch_id'];?></option>
									<?php
								}
									?>
								</select>
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Date of booking :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="dateofbooking" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"> book at Branch :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="booked_at_branch" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Branch location :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="branchlocation" placeholder="Enter branch location" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">destination :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="destination" placeholder="Enter name" required="" id="dearname">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver name :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="reciver_name" placeholder="Enter Reciver name" required="" id="dearname">
							</div>
						</div>
						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Address :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="rciveraddress" placeholder="Enter Reciver Address" required="">
							</div>
						</div>

						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label">Reciver Phone no :</label>
							<div class="col-sm-8">
								<input type="text" class="form-control1" name="Reciver_phone_no" placeholder="Enter Reciver Phone no" required="" >
							</div>
						</div>-->



						<div class="form-group">
							<label for="focusedinput" class="col-sm-2 control-label"></label>
							<div class="col-sm-8">
								<button type="Submit" class="btn btn-success" name="Customer">Submit</button>
								<a href=""><button type="button" class="btn btn-danger">Cancel</button></a>
							</div>
						</div>

					</form>
				</div>
			</div>
			
			
			
			<div id="page-wrapper">
  <div class="graphs">
    

    <div class="xs tabls">
      <div class="bs-example4" data-example-id="contextual-table" style="overflow-y: scroll;">
        <table class="table table-hover" id="example" class="display" width="100%" cellspacing="0">
          <thead>
            <tr>
            
            <th>Id</th>
            <th>Customer Name</th>
            <th>Courier Name</th>
              <th>Zone Type</th>
              <th>City</th>
              <th>State</th>
              <th>Location</th>
              <th>Character</th>
              <th>Number</th>
              <th>Expo Character</th>
              <th>Expo Number</th>
              
             

            </tr>
          </thead>
          <tbody>
          <?php 
            $sql="Select * from zone order by id desc limit 3";
            $res=mysqli_query($conn,$sql);
            $i=1;
            while($ros=mysqli_fetch_array($res))
            {
              ?>
          <tr>

            
             <td><?php echo $ros['id'];?></td>
             <td><?php echo $ros['customer_name'];?></td>
			<td><?php echo $ros['courier_name'];?></td>
            <td><?php echo $ros['zone_type'];?></td>
            <td><?php echo $ros['city'];?></td>
            <td><?php echo $ros['state'];?></td>
            <td><?php echo $ros['location'];?></td>
            <td><?php echo $ros['char'];?></td>
            <td><?php echo $ros['number'];?></td>
             <td><?php echo $ros['expo_char'];?></td>
            <td><?php echo $ros['expo_number'];?></td>
            
            
            
            

          </tr>
          <?php

        }
        ?>
       

          </tbody>


        </table>
      </div>
    </div>
  </div>
</div>
			<!--body wrapper start-->
		</div>
		<!--body wrapper end-->
	</div>


	<?php 
	include('footer.php');

	if(isset($_REQUEST['Customer']))
	{
$customer_name=$_REQUEST['customer_name'];
$courier_name=$_REQUEST['courier_name'];
$zone_type=$_REQUEST['zone_type'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$location=$_REQUEST['location'];
$char=$_REQUEST['char'];
$number=$_REQUEST['number'];
$expo_char=$_REQUEST['expo_char'];
$expo_number=$_REQUEST['expo_number'];
date_default_timezone_set("Asia/Calcutta");
$date=date('Y-m-d h:i:s'); 
$ccn="Book".time();
$bookingid="BOOK".time();
		


		$sql="INSERT INTO `zone` (`datetime`, `customer_name`, `courier_name`, `zone_type`, `city`, `state`, `location`, `char`, `number`, `expo_char`, `expo_number`) VALUES 
		('$date', '$customer_name', '$courier_name', '$zone_type', '$city', '$state', '$location', '$char', '$number', '$expo_char', '$expo_number')";

		$res=mysqli_query($conn,$sql);

		if($res)
		{
			echo '<script>
				swal("Successfully Added", {
				title: "Added!",
				text: "zone Added Successfully",
				icon: "success",
				
                
				button: "View zone",
				}).then(function () {
				window.location.href = "view_zone.php"});
				</script>' ;
		}
		else
		{
			echo '<script>
				swal("Error occured", {
				title: "Error!",
				text: "Error in Adding zone. Please contact System Administrator",
				icon: "error",
				button: "OK",
				}).then(function () {
				window.location.href = "add_zone.php"});
				</script>' ;

		}

	}
	?>


