<html>
<?php
include('new2.php');
?>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
</head>

<body>
<style>
body{
   background-image:url('image/bg3.jpg');
   -webkit-background-size:cover;
  -moz-webkit-background-size:cover;
   background-size:cover;
   width:100%;
   height:100%;
	 
   
}
.pos{
	color:black;
	//background-color:#333333;
	margin-left:0px;
	margin-top:10px;
	background-color:#f1f1f1;
	
}
</style>

<form method="POST">
<div class="container">
<div class="col-md-12 col-lg-12">







<div class="col-md-6 offset-2">
	<div class="well pos ">
			
			
			<div class="panel panel-primary">
<div class="panel-heading">
<h1 style="color:white;font-style:arial;font-size:24;text-align:center">
<span class="glyphicon glyphicon-">&nbsp;<strong>Add Question</strong></span></h1>
</div>
</div>
			
			<div class="col-md-6-offset-2"><input type="hidden" name="sub_name" id= value="" 
			placeholder="Select subject name" required>
			<?php
			error_reporting('E_ALL');
	include('conn.php');
	$q="select subject_code,subject_name from tb_subject";
	$res=mysqli_query($con,$q);
	?>
	
  <select name="subjects"  class="form-control"  required>
  <option value="0">Select subject name</option>
  <?php
	while($row=mysqli_fetch_array($res))
	{
		$sub_name=$row['subject_name'];
		$sub_code=$row['subject_code'];
		
		echo "<option value='$sub_code'>$sub_name</option>";
	} ?>
  </select>
			
			
			
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="que"  value="" class="form-control" 
			placeholder="Enter question" required>
			</div><br>
			<div class="col-md-6-offset-2"><textarea rows="3" cols="64" name="prog" placeholder="Write a program ..."></textarea>
			</div><br>
			
			
			<div class="col-md-6-offset-2"><input type="text" name="ch1" id="" value="" class="form-control" 
			placeholder="Enter choice 1" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="ch2" id="" value="" class="form-control" 
			placeholder="Enter choice 2" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="ch3" id="" value="" class="form-control" 
			placeholder="Enter choice 3" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="ch4" id="" value="" class="form-control" 
			placeholder="Enter choice 4" required>
			</div><br>
			
			
			
			<div class="col-md-6-offset-2" >
			<!--<label style="color:">Correct answer</label>-->
			<select name="ans"  class="form-control">
			<option value="0">Select correct answer</option>
			<option value="ch1">choice_1</option>
			<option value="ch2">choice_2</option>
			<option value="ch3">choice_3</option>
			<option value="ch4">choice_4</option>
			</select>
			</div><br>
			
		
			
            <div class="text-justify" style="margin-left:150px">	
					 <button type="submit" name="submit" value="Add Question" class="btn btn-danger" >
					 <span class="glyphicon glyphicon-"></span> Add Question
					</button>
					
				
			</div>


	</div>
</div>


</div>
</div>
</form>
</body>
</html>
<?php
$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);

if($con)
{
	
	
if(isset($_POST['submit']))
{
echo"connection successfull.....!";
	echo $sub_code=$_POST['subjects'];
	$que=$_POST['que'];
	$prog=$_POST['prog'];
	$ch1=$_POST['ch1'];
	$ch2=$_POST['ch2'];
	$ch3=$_POST['ch3'];
	$ch4=$_POST['ch4'];
	$s=$_POST['ans'];
	$ans=$_POST[$_POST['ans']];
	if($sub_code=='0' && $s=='0')//subject code must be selected its not submitted as blank since this condition
	{
		echo"<script>alert('please select subject name & correct answer..!')</script>";
    }
	elseif($s=='0')
	{
		echo"<script>alert('please select Correct ans')</script>";
		
	}
	elseif($sub_code=='0')
	{
		echo "<br>";
		echo $ans;
		echo"<script>alert('please select Subject Name')</script>";
	}	
	else
	{		
		$query="insert into tb_question(Question,Program,Choice1,Choice2,Choice3,Choice4,Correct_ans,subject_code)
		values('$que','$prog','$ch1','$ch2','$ch3','$ch4','$ans','$sub_code')";
		$sql=mysqli_query($con,$query);
		//$row=mysqli_fetch_array($sql);
	
	}
}
}
?>