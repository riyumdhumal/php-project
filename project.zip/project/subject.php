<!DOCTYPE html>

<?php
session_start();
$u_type=$_SESSION['user_type'];
$u_name=$_SESSION['name'];

?>

<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body {
  margin: 0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: auto;
}

@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin:0px;
	
}
</style>
</head>
<body>
<div class="header">
<h4 class=""><b style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;Online Examination System
</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i   class='fa fa-fw fa-sign-out'><a href="logout.php"> Sign-out</a></i> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user"></i>&nbsp;&nbsp;<?php echo $u_name."(".$u_type.")";
?>&nbsp;&nbsp;

</h4>
</div>

<div class="sidebar">
  <a class="active" href="#home"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
  <a href="subject.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Add Subject</a>
  <a href="Quize.php"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Add Questions</a>
  
 <a href="Viewque.php"><i style="font-size:30px;" class="fas fa-question-circle"></i><br>View Questions</a>
 <a href="Report1.php"><i style="font-size:30px;" class="material-icons">&#xe1b8;</i><br>Reports</a>
  <a href="#about"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
</div>

<div class="content">
 
 <style>
.pos{
	color:black;
	background-color:#f1f1f1;
	margin-top:30px;
	margin-left:50px;
}
</style>

<form method="GET" style="margin-top:50px;">
<div class="container text-center">
<div class="col-md-12 col-lg-12">

<?php $error="";?>
<div class="col-md-6 offset-2">
	<div class="well pos ">
			
			
<div class="panel panel-primary">
<div class="panel-heading">
<h3 style="color:white;font-style:arial;font-size:18;text-align:center">
<span class="glyphicon glyphicon-">&nbsp;<strong>Add Subject</strong></span></h3>
</div>
</div>
			
			<div class="col-md-6-offset-2"><input type="text" name="subject_code" id= value="" class="form-control" 
		
		placeholder="Enter subject code" required>
			</div><br><?phpecho $error; ?>
			
			<div class="col-md-6-offset-2"><input type="text" name="subject_name"  value="" class="form-control" 
			placeholder="Enter subject name" required>
			</div><br>
			
			
			
		<!--	<div class="col-md-6-offset-2"><input type="text" name="total_question" id="" value="" class="form-control" 
			placeholder="Enter total no of questions" required>
			</div><br>
			
			<div class="col-md-6-offset-2"><input type="text" name="marks" id="" value="" class="form-control" 
			placeholder="Enter Marks" required>
			</div><br>-->
			
			
			
		<!--<div class="col-md-6-offset-2" class="form-control">
			<label style="color:white">Correct answer</label>
			<select name="ans">
			<option value="">select answer</option>
			<option value="ch1">choice_1</option>
			<option value="ch2">choice_2</option>
			<option value="ch3">choice_3</option>
			<option value="ch4">choice_4</option>
			</select>
			</div><br>-->
			
		
			
            <div class="text-justify" style="margin-left:150px">	
					 <button type="submit" name="submit" value="submit" class="btn btn-danger" >
					 <span class="glyphicon glyphicon-"></span> submit
					</button>
					
				
			</div><br><br>


	</div>
</div>


</div>
</div>
</form>
</body>
</html>
<?php
error_reporting('E_ALL');
$error;
$username="root";
$pass="";
$servername="localhost";
$dbname="exam";

$con=mysqli_connect($servername,$username,$pass,$dbname);

if($con)
{
	
	
if(isset($_GET['submit']))
{
echo"connection successfull.....!";
	
	$subject_code=$_GET['subject_code'];
	$subject_name=$_GET['subject_name'];
	$total_question=$_GET['total_question'];
	$marks=$_GET['marks'];
	$_session['sub_code']=$_GET['subject_code'];
	//echo$_session['sub_code'];
	
	$q="select subject_code from tb_subject where subject_code=$subject_code";
	$s=mysqli_query($con,$q);
	 $num=mysqli_num_rows($s);
	if($num==1)
	{
		echo"<script>alert('Subject Code is already in use..!please Enter another code')</script>";
//$error='Subject Code is already in use... please Enter another code';
		
	}
	else
	{
	
	$query="insert into tb_subject(subject_code,subject_name,total_question,marks)
	values('$subject_code','$subject_name','$total_question','$marks')";
	$sql=mysqli_query($con,$query);
	//$row=mysqli_fetch_array($sql);
	echo"<script>alert('Subject added Successfully ....')</script>";
}
}
}
?>
 
 
 
</div>

</body>
</html>
