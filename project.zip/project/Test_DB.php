
 <?php
 session_start();
 date_default_timezone_set('Asia/Kolkata');
  $start_time=date('yy-m-d h:i:s');
 //include('subject.php');
 $scode=$_GET['id'];
 $_SESSION['sub_code']=$scode;
$_SESSION['start_time']=$start_time;
$u_type=$_SESSION['user_type'];
 
 //echo $scode;
 ?>


<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css"  href="css/bootstrap.css">
<link rel="stylesheet" type="text/css"  href="css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>

body {
  margin: 0px 0px 0px 0px;
  font-family: "Lato", sans-serif;
  text-align:;
}

.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
  text-align:center;
 
}
 
.sidebar a.active {
  background-color: #4CAF50;
  color: white;
}

.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: ;
  

}



@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}

.header{
	background-color:#f1f1f1;
	height:60px;
	margin-top:0px;
	
	
}


.animateuse{
	animation:headanimate 0.5s infinite;
	
}
@keyframes headanimate{
	
	0%{color:red},
	10%{color:yellow},
	20%{color:blue},
	40%{color:green},
	50%{color:pink},
	60%{color:orange},
	80%{color:black},
	100%{color:brown}
	
}

.sticky {
  position: fixed;
  top: 0;
  width: 100%;
}

.sticky + .content {
  padding-top: 102px;
}




</style>




</head>
<body>
<div class="header" id="myHeader">
<h4 class=" text-success "><b  style="padding-top:10px !important;"> &nbsp;&nbsp;
<i style="font-size:40px;" class='fa fa-fw fa-laptop'></i> &nbsp;&nbsp;&nbsp;<i class="animateuse">Online Examination System
</i></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i   class='fa fa-fw fa-sign-out'><a href="logout.php"> Sign-out</a></i> </button>
<button style="font-size:15px;float:right;margin-top:20px;margin-right:50px;" class="btn btn">
<i  class="fa fa-fw fa-user">&nbsp;&nbsp;</i><?php echo $_SESSION['name']."(".$u_type.")";?>
</button>		`	

</h4>
</div>

<div class="sidebar" >
  <a class="active" href="new.php"><i style="font-size:30px;" class="fa fa-fw fa-home"></i><br>Dashboard</a>
  <a href="exam.php"><i style="font-size:30px;" class="fa fa-fw fa-pencil-square-o"></i><br>Exam</a>
  <a href="#contact"><i style="font-size:30px;" class="fa fa-fw fa-book"></i><br>Subject</a>
  <a href="#about"><i style="font-size:30px;" class="fa fa-fw fa-address-book"></i><br>About</a>
</div>
	<div class="content" >
	<div class="cointaner">
<div class="col-md-12 col-lg-12 col-sm-12">
<div class="panel panel-primary" style="position:;">
<div class="panel-heading text-center">
<h2 style={"color:black;"}><b>Welcome <?php  echo$_SESSION['name'];?> In Quize
 <span class="glyphicon glyphicon-king"></span> &nbsp;&nbsp;World. </b> </h2>
</div></div>
<form method="POST" action="check.php">
	
	
	<div class="col-md-8-offset-2" style="margin-top:80px;">
	<div class="panel panel-body">
	<?php
	error_reporting(0);
if(isset($_SESSION['name']))
{
	//$scode=$_GET['subject_code'];
	//echo $scode;
	include('conn.php');
	$q="SELECT Question,Program,Q_id FROM tb_question where subject_code='$scode'";
	$res=mysqli_query($con,$q);	
	$i=1;
	while($row=mysqli_fetch_array($res))
	{
		//echo $i.']&nbsp';
		?>
				<div class="panel panel-default">
				<div class="panel-heading">
				<?php
				  echo $i.']&nbsp'.$row['Question'];
				?>
				</div></div>
				
		<?php
		$qid=$row['Q_id'];
		echo "<br>";
		$prog=$row['Program'];

		if(!empty($prog))
		{
		?>
			<textarea readonly cols="25" rows="6" name="quize[<?php echo $row['Q_id'];?>]" value="<?php echo $row['Program'];?>"> 
			<?php echo $row['Program'];?> </textarea><br>
		
		<?php
		}
		$q1="SELECT Q_id,Program,Correct_ans,Choice1,Choice2,Choice3,Choice4 FROM tb_question where Q_id='$qid'";
		$res1=mysqli_query($con,$q1);
		while($row1=mysqli_fetch_array($res1))
				{?>
					<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice1'];?>"><?php echo $row1['Choice1'];?><br>
					<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice2'];?>"><?php echo $row1['Choice2'];?><br>
					<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice3'];?>"><?php echo $row1['Choice3'];?><br>
					<input type="radio" name="quizecheck[<?php echo $row1['Q_id'];?>]" value="<?php echo $row1['Choice4'];?>"><?php echo $row1['Choice4'];?><br>
					<br>
				<?php }
		$i++;
	}
	$_SESSION['$tq']=$i-1;
	
}else
{
	header('location:login.php');
}


	?>  
 
  
	<div class="text-center">
      <input type="submit" name="submit" value="submit" class="btn btn-success " style="margin-left:0px;">
   </div>
   
   </div><br><br><br>


<!--<div class="text-center">
<a href="logout.php" class="btn btn-primary">LOGOUT</a>
</div>-->


</div>

</div>
</div>
 </form> 
</div>

<!--script for sticky header-->
<script>
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("sticky");
  } else {
    header.classList.remove("sticky");
  }
}

</script>


		

</body>
</html>

<?php
if(isset($_POST['submit']))
{
echo"connection successfull.....!";
	
	$subject_code=$_POST['subject_code'];
	$subject_name=$_POST['subject_name'];
	$total_question=$_POST['total_question'];
	$marks=$_POST['marks'];
	
	
	$query="insert into tb_student(user_id,subject_code,total_question,Question_attened,total_marks,Obtained_marks)
	values('$user_id','$subject_code','$total_question','$Q_attended','$t_marks','$obt_marks')";
	$sql=mysqli_query($con,$query);
	//$row=mysqli_fetch_array($sql);
	
}
?>